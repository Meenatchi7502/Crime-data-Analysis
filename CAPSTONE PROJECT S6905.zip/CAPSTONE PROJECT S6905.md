# INSTALLATION PART


```python
pip install pymysql
```

    Requirement already satisfied: pymysql in c:\users\user\anaconda3\new folder\odin\lib\site-packages (1.1.0)
    Note: you may need to restart the kernel to use updated packages.
    


```python
import pymysql
```


```python
pip install pandas
```

    Requirement already satisfied: pandas in c:\users\user\anaconda3\new folder\odin\lib\site-packages (2.0.3)
    Requirement already satisfied: python-dateutil>=2.8.2 in c:\users\user\anaconda3\new folder\odin\lib\site-packages (from pandas) (2.8.2)
    Requirement already satisfied: pytz>=2020.1 in c:\users\user\anaconda3\new folder\odin\lib\site-packages (from pandas) (2023.3.post1)
    Requirement already satisfied: tzdata>=2022.1 in c:\users\user\anaconda3\new folder\odin\lib\site-packages (from pandas) (2023.3)
    Requirement already satisfied: numpy>=1.21.0 in c:\users\user\anaconda3\new folder\odin\lib\site-packages (from pandas) (1.24.3)
    Requirement already satisfied: six>=1.5 in c:\users\user\anaconda3\new folder\odin\lib\site-packages (from python-dateutil>=2.8.2->pandas) (1.16.0)
    Note: you may need to restart the kernel to use updated packages.
    


```python
pip install mysql-connector
```

    Requirement already satisfied: mysql-connector in c:\users\user\anaconda3\new folder\odin\lib\site-packages (2.2.9)Note: you may need to restart the kernel to use updated packages.
    
    


```python
pip install matplotlib
```

    Requirement already satisfied: matplotlib in c:\users\user\anaconda3\new folder\odin\lib\site-packages (3.7.2)
    Requirement already satisfied: contourpy>=1.0.1 in c:\users\user\anaconda3\new folder\odin\lib\site-packages (from matplotlib) (1.0.5)
    Requirement already satisfied: cycler>=0.10 in c:\users\user\anaconda3\new folder\odin\lib\site-packages (from matplotlib) (0.11.0)
    Requirement already satisfied: fonttools>=4.22.0 in c:\users\user\anaconda3\new folder\odin\lib\site-packages (from matplotlib) (4.25.0)
    Requirement already satisfied: kiwisolver>=1.0.1 in c:\users\user\anaconda3\new folder\odin\lib\site-packages (from matplotlib) (1.4.4)
    Requirement already satisfied: numpy>=1.20 in c:\users\user\anaconda3\new folder\odin\lib\site-packages (from matplotlib) (1.24.3)
    Requirement already satisfied: packaging>=20.0 in c:\users\user\anaconda3\new folder\odin\lib\site-packages (from matplotlib) (23.1)
    Requirement already satisfied: pillow>=6.2.0 in c:\users\user\anaconda3\new folder\odin\lib\site-packages (from matplotlib) (9.4.0)
    Requirement already satisfied: pyparsing<3.1,>=2.3.1 in c:\users\user\anaconda3\new folder\odin\lib\site-packages (from matplotlib) (3.0.9)
    Requirement already satisfied: python-dateutil>=2.7 in c:\users\user\anaconda3\new folder\odin\lib\site-packages (from matplotlib) (2.8.2)
    Requirement already satisfied: six>=1.5 in c:\users\user\anaconda3\new folder\odin\lib\site-packages (from python-dateutil>=2.7->matplotlib) (1.16.0)
    Note: you may need to restart the kernel to use updated packages.
    


```python
pip install seaborn
```

    Requirement already satisfied: seaborn in c:\users\user\anaconda3\new folder\odin\lib\site-packages (0.12.2)
    Requirement already satisfied: numpy!=1.24.0,>=1.17 in c:\users\user\anaconda3\new folder\odin\lib\site-packages (from seaborn) (1.24.3)
    Requirement already satisfied: pandas>=0.25 in c:\users\user\anaconda3\new folder\odin\lib\site-packages (from seaborn) (2.0.3)
    Requirement already satisfied: matplotlib!=3.6.1,>=3.1 in c:\users\user\anaconda3\new folder\odin\lib\site-packages (from seaborn) (3.7.2)
    Requirement already satisfied: contourpy>=1.0.1 in c:\users\user\anaconda3\new folder\odin\lib\site-packages (from matplotlib!=3.6.1,>=3.1->seaborn) (1.0.5)
    Requirement already satisfied: cycler>=0.10 in c:\users\user\anaconda3\new folder\odin\lib\site-packages (from matplotlib!=3.6.1,>=3.1->seaborn) (0.11.0)
    Requirement already satisfied: fonttools>=4.22.0 in c:\users\user\anaconda3\new folder\odin\lib\site-packages (from matplotlib!=3.6.1,>=3.1->seaborn) (4.25.0)
    Requirement already satisfied: kiwisolver>=1.0.1 in c:\users\user\anaconda3\new folder\odin\lib\site-packages (from matplotlib!=3.6.1,>=3.1->seaborn) (1.4.4)
    Requirement already satisfied: packaging>=20.0 in c:\users\user\anaconda3\new folder\odin\lib\site-packages (from matplotlib!=3.6.1,>=3.1->seaborn) (23.1)
    Requirement already satisfied: pillow>=6.2.0 in c:\users\user\anaconda3\new folder\odin\lib\site-packages (from matplotlib!=3.6.1,>=3.1->seaborn) (9.4.0)
    Requirement already satisfied: pyparsing<3.1,>=2.3.1 in c:\users\user\anaconda3\new folder\odin\lib\site-packages (from matplotlib!=3.6.1,>=3.1->seaborn) (3.0.9)
    Requirement already satisfied: python-dateutil>=2.7 in c:\users\user\anaconda3\new folder\odin\lib\site-packages (from matplotlib!=3.6.1,>=3.1->seaborn) (2.8.2)
    Requirement already satisfied: pytz>=2020.1 in c:\users\user\anaconda3\new folder\odin\lib\site-packages (from pandas>=0.25->seaborn) (2023.3.post1)
    Requirement already satisfied: tzdata>=2022.1 in c:\users\user\anaconda3\new folder\odin\lib\site-packages (from pandas>=0.25->seaborn) (2023.3)
    Requirement already satisfied: six>=1.5 in c:\users\user\anaconda3\new folder\odin\lib\site-packages (from python-dateutil>=2.7->matplotlib!=3.6.1,>=3.1->seaborn) (1.16.0)
    Note: you may need to restart the kernel to use updated packages.
    

# CONNECTION PART:


```python
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import pymysql
import mysql.connector
```


```python
connection = pymysql.connect(
    host ="localhost",
    user="root",
    password="#Sunder7502",
    database="crime"
)
```


```python
cursor = connection.cursor()
```

# BASIC STATISTICS ON THE DATASET


```python
cursor.execute("select * from crime_data")
rows = cursor.fetchall()

for row in rows:
    print(row)
```

    (10304468, '01-08-2020', '01-08-2020', 'Southwest', 624, 'BATTERY - SIMPLE ASSAULT', 36, 'F', 'SINGLE FAMILY DWELLING', 'AO', '1100 W 39TH PL', 34.01, -118.3)
    (190101086, '01-02-2020', '01-01-2020', 'Central', 624, 'BATTERY - SIMPLE ASSAULT', 25, 'M', 'SIDEWALK', 'IC', '700 S HILL ST', 34.05, -118.25)
    (191501505, '01-01-2020', '01-01-2020', 'N Hollywood', 745, 'VANDALISM - MISDEAMEANOR ($399 OR UNDER)', 76, 'F', 'MULTI-UNIT DWELLING (APARTMENT, DUPLEX, ETC)', 'IC', '5400 CORTEEN PL', 34.17, -118.4)
    (191921269, '01-01-2020', '01-01-2020', 'Mission', 740, 'VANDALISM - FELONY ($400 & OVER, ALL CHURCH VANDALISMS)', 31, 'X', 'BEAUTY SUPPLY STORE', 'IC', '14400 TITUS ST', 34.22, -118.45)
    (200100502, '01-02-2020', '01-02-2020', 'Central', 442, 'SHOPLIFTING - PETTY THEFT ($950 & UNDER)', 23, 'M', 'DEPARTMENT STORE', 'IC', '700 S FIGUEROA ST', 34.05, -118.26)
    (200100504, '01-04-2020', '01-04-2020', 'Central', 946, 'OTHER MISCELLANEOUS CRIME', 0, 'X', 'POLICE FACILITY', 'IC', '200 E 6TH ST', 34.04, -118.25)
    (200100507, '01-04-2020', '01-04-2020', 'Central', 341, 'THEFT-GRAND ($950.01 & OVER)EXCPT,GUNS,FOWL,LIVESTK,PROD', 23, 'M', 'MULTI-UNIT DWELLING (APARTMENT, DUPLEX, ETC)', 'IC', '700 BERNARD ST', 34.07, -118.24)
    (200100509, '01-04-2020', '01-04-2020', 'Central', 330, 'BURGLARY FROM VEHICLE', 29, 'M', 'STREET', 'IC', '800 N ALAMEDA ST', 34.04, -118.26)
    (200100510, '01-05-2020', '01-05-2020', 'Central', 930, 'CRIMINAL THREATS - NO WEAPON DISPLAYED', 35, 'M', 'PARKING LOT', 'IC', '800 S OLIVE ST', 34.06, -118.24)
    (200100514, '01-05-2020', '01-05-2020', 'Central', 341, 'THEFT-GRAND ($950.01 & OVER)EXCPT,GUNS,FOWL,LIVESTK,PROD', 41, 'M', 'HOTEL', 'AA', '700 W 7TH ST', 34.05, -118.26)
    (200100515, '01-07-2020', '01-07-2020', 'Central', 648, 'ARSON', 0, 'X', 'DEPARTMENT STORE', 'IC', '100 S LOS ANGELES ST', 34.05, -118.26)
    (200100520, '01-08-2020', '01-08-2020', 'Central', 442, 'SHOPLIFTING - PETTY THEFT ($950 & UNDER)', 24, 'F', "COFFEE SHOP (STARBUCKS, COFFEE BEAN, PEET'S, ETC.)", 'IC', '13600 LEADWELL ST', 34.05, -118.24)
    (200914517, '09-10-2020', '09-09-2020', 'Van Nuys', 354, 'THEFT OF IDENTITY', 40, 'M', 'CONDOMINIUM/TOWNHOUSE', 'IC', '8TH', 34.2, -118.43)
    (200716724, '12-04-2020', '12-03-2020', 'Wilshire', 442, 'SHOPLIFTING - PETTY THEFT ($950 & UNDER)', 19, 'M', 'OTHER BUSINESS', 'IC', 'WALL', 34.08, -118.37)
    (200100583, '02-04-2020', '02-04-2020', 'Central', 230, 'ASSAULT WITH DEADLY WEAPON, AGGRAVATED ASSAULT', 38, 'F', 'OTHER BUSINESS', 'AA', '800 N BROADWAY', 34.05, -118.25)
    (200100584, '02-04-2020', '02-04-2020', 'Central', 442, 'SHOPLIFTING - PETTY THEFT ($950 & UNDER)', 55, 'M', 'DEPARTMENT STORE', 'IC', '400 S SPRING ST', 34.05, -118.26)
    (200100587, '02-06-2020', '02-06-2020', 'Central', 740, 'VANDALISM - FELONY ($400 & OVER, ALL CHURCH VANDALISMS)', 66, 'F', 'VEHICLE, PASSENGER/TRUCK', 'IC', '300 W 5TH ST', 34.04, -118.25)
    (200218458, '12-11-2020', '12-11-2020', 'Rampart', 761, 'BRANDISH WEAPON', 34, 'M', 'PARKING LOT', 'AO', '1800 S MAIN ST', 34.07, -118.28)
    (200100596, '02-08-2020', '02-08-2020', 'Central', 442, 'SHOPLIFTING - PETTY THEFT ($950 & UNDER)', 35, 'M', 'OTHER STORE', 'IC', '600 W 7TH ST', 34.05, -118.26)
    (200104020, '01-01-2020', '01-01-2020', 'Central', 350, 'THEFT, PERSON', 44, 'M', 'SIDEWALK', 'IC', '700 ALPINE ST', 34.05, -118.25)
    (200104024, '01-01-2020', '01-01-2020', 'Central', 740, 'VANDALISM - FELONY ($400 & OVER, ALL CHURCH VANDALISMS)', 41, 'M', 'VEHICLE, PASSENGER/TRUCK', 'IC', '6200 SYLMAR AV', 34.05, -118.25)
    (200104027, '01-01-2020', '01-01-2020', 'Central', 930, 'CRIMINAL THREATS - NO WEAPON DISPLAYED', 57, 'M', 'PARKING LOT', 'IC', '100 E 5TH ST', 34.05, -118.26)
    (200104035, '01-01-2020', '01-01-2020', 'Central', 310, 'BURGLARY', 34, 'F', 'MULTI-UNIT DWELLING (APARTMENT, DUPLEX, ETC)', 'IC', '1200 E 7TH ST', 34.06, -118.24)
    (200104038, '01-01-2020', '01-01-2020', 'Central', 230, 'ASSAULT WITH DEADLY WEAPON, AGGRAVATED ASSAULT', 57, 'M', 'SIDEWALK', 'IC', '700 S FLOWER ST', 34.04, -118.25)
    (200104039, '01-01-2020', '01-01-2020', 'Central', 745, 'VANDALISM - MISDEAMEANOR ($399 OR UNDER)', 55, 'M', 'OTHER BUSINESS', 'IC', '300 E 3RD ST', 34.05, -118.26)
    (200104041, '01-01-2020', '01-01-2020', 'Central', 480, 'BIKE - STOLEN', 23, 'M', 'RESTAURANT/FAST FOOD', 'IC', '1ST', 34.03, -118.27)
    (200104043, '01-01-2020', '01-01-2020', 'Central', 745, 'VANDALISM - MISDEAMEANOR ($399 OR UNDER)', 55, 'M', 'VEHICLE, PASSENGER/TRUCK', 'IC', '1200 S GRAND AV', 34.06, -118.24)
    (200104047, '01-01-2020', '01-01-2020', 'Central', 623, 'BATTERY POLICE (SIMPLE)', 0, 'X', 'MTA - RED LINE - PERSHING SQUARE', 'IC', '300 S GRAND AV', 34.05, -118.25)
    (200104048, '01-01-2020', '01-01-2020', 'Central', 623, 'BATTERY POLICE (SIMPLE)', 0, 'X', 'MTA - RED LINE - PERSHING SQUARE', 'IC', '600 S CENTRAL AV', 34.05, -118.25)
    (200104051, '01-01-2020', '01-01-2020', 'Central', 440, 'THEFT PLAIN - PETTY ($950 & UNDER)', 22, 'F', 'NIGHT CLUB (OPEN EVENINGS ONLY)', 'IC', '600 N BROADWAY', 34.05, -118.26)
    (200104054, '01-02-2020', '01-01-2020', 'Central', 624, 'BATTERY - SIMPLE ASSAULT', 28, 'M', 'MULTI-UNIT DWELLING (APARTMENT, DUPLEX, ETC)', 'IC', '800 W 7TH ST', 34.05, -118.25)
    (200104057, '01-02-2020', '01-01-2020', 'Central', 230, 'ASSAULT WITH DEADLY WEAPON, AGGRAVATED ASSAULT', 43, 'M', 'STREET', 'IC', '7TH ST', 34.04, -118.25)
    (200104058, '01-02-2020', '01-01-2020', 'Central', 624, 'BATTERY - SIMPLE ASSAULT', 46, 'M', 'SIDEWALK', 'IC', '23400 PRESIDENT AV', 34.05, -118.24)
    (200104060, '01-02-2020', '01-01-2020', 'Central', 624, 'BATTERY - SIMPLE ASSAULT', 56, 'F', 'STREET', 'IC', '700 W 7TH ST', 34.05, -118.25)
    (200104063, '01-01-2020', '01-01-2020', 'Central', 341, 'THEFT-GRAND ($950.01 & OVER)EXCPT,GUNS,FOWL,LIVESTK,PROD', 55, 'F', 'PARKING LOT', 'IC', '13100 LAKE ST', 34.05, -118.26)
    (200104065, '01-01-2020', '01-01-2020', 'Central', 745, 'VANDALISM - MISDEAMEANOR ($399 OR UNDER)', 55, 'M', 'MULTI-UNIT DWELLING (APARTMENT, DUPLEX, ETC)', 'IC', '100 W 1ST ST', 34.06, -118.23)
    (200104066, '01-01-2020', '01-01-2020', 'Central', 745, 'VANDALISM - MISDEAMEANOR ($399 OR UNDER)', 0, 'X', 'VEHICLE, PASSENGER/TRUCK', 'IC', '3RD', 34.04, -118.26)
    (200104069, '01-02-2020', '01-02-2020', 'Central', 310, 'BURGLARY', 0, 'X', 'RESTAURANT/FAST FOOD', 'IC', '6TH', 34.06, -118.24)
    (200104073, '01-02-2020', '01-02-2020', 'Central', 510, 'VEHICLE - STOLEN', 0, '', 'PARKING LOT', 'IC', '1ST', 34.05, -118.25)
    (200104075, '01-02-2020', '01-01-2020', 'Central', 440, 'THEFT PLAIN - PETTY ($950 & UNDER)', 67, 'M', 'MULTI-UNIT DWELLING (APARTMENT, DUPLEX, ETC)', 'IC', '1600 S HOPE ST', 34.04, -118.25)
    (200104076, '01-01-2020', '01-01-2020', 'Central', 341, 'THEFT-GRAND ($950.01 & OVER)EXCPT,GUNS,FOWL,LIVESTK,PROD', 57, 'M', 'MULTI-UNIT DWELLING (APARTMENT, DUPLEX, ETC)', 'IC', '600 W 7TH ST', 34.05, -118.25)
    (200104077, '01-02-2020', '01-01-2020', 'Central', 330, 'BURGLARY FROM VEHICLE', 37, 'F', 'STREET', 'IC', '600 S SAN PEDRO ST', 34.03, -118.26)
    (200104078, '01-02-2020', '01-02-2020', 'Central', 210, 'ROBBERY', 0, 'X', 'DRUG STORE', 'IC', '100 W 2ND ST', 34.05, -118.26)
    (200104082, '01-02-2020', '01-02-2020', 'Central', 624, 'BATTERY - SIMPLE ASSAULT', 60, 'M', 'STREET', 'IC', '100 E 5TH ST', 34.04, -118.25)
    (200104090, '01-02-2020', '01-02-2020', 'Central', 442, 'SHOPLIFTING - PETTY THEFT ($950 & UNDER)', 0, 'M', 'DEPARTMENT STORE', 'IC', '700 W 7TH ST', 34.05, -118.26)
    (200104092, '01-02-2020', '01-01-2020', 'Central', 310, 'BURGLARY', 51, 'M', 'GARAGE/CARPORT', 'IC', '700 W 7TH ST', 34.06, -118.24)
    (200918185, '12-07-2020', '12-07-2020', 'Van Nuys', 900, 'VIOLATION OF COURT ORDER', 52, 'F', 'GOVERNMENT FACILITY (FEDERAL,STATE, COUNTY & CITY)', 'AA', '4TH', 34.18, -118.45)
    (200104098, '01-02-2020', '01-02-2020', 'Central', 210, 'ROBBERY', 61, 'M', 'MULTI-UNIT DWELLING (APARTMENT, DUPLEX, ETC)', 'AO', '700 S GRAND AV', 34.05, -118.25)
    (200104118, '01-02-2020', '01-02-2020', 'Central', 624, 'BATTERY - SIMPLE ASSAULT', 36, 'F', 'OTHER BUSINESS', 'IC', '5TH', 34.04, -118.24)
    (200104120, '01-02-2020', '01-02-2020', 'Central', 310, 'BURGLARY', 59, 'M', "SINGLE RESIDENCE OCCUPANCY (SRO'S) LOCATIONS", 'IC', '100 E 5TH ST', 34.04, -118.24)
    (200104126, '01-02-2020', '01-02-2020', 'Central', 442, 'SHOPLIFTING - PETTY THEFT ($950 & UNDER)', 32, 'M', 'OTHER STORE', 'IC', '100 W 2ND ST', 34.05, -118.26)
    (200104127, '01-02-2020', '01-02-2020', 'Central', 888, 'TRESPASSING', 44, 'F', 'PARKING UNDERGROUND/BUILDING', 'IC', 'PALMETTO', 34.05, -118.24)
    (200104129, '01-02-2020', '01-02-2020', 'Central', 230, 'ASSAULT WITH DEADLY WEAPON, AGGRAVATED ASSAULT', 60, 'F', 'STREET', 'IC', '800 JAMES M WOOD BL', 34.05, -118.24)
    (200104132, '01-02-2020', '01-02-2020', 'Central', 330, 'BURGLARY FROM VEHICLE', 31, 'M', 'PARKING LOT', 'IC', 'GRAND', 34.04, -118.26)
    (200104135, '01-02-2020', '01-02-2020', 'Central', 440, 'THEFT PLAIN - PETTY ($950 & UNDER)', 30, 'M', 'STREET', 'IC', 'GRAND', 34.05, -118.25)
    (200104136, '01-02-2020', '01-02-2020', 'Central', 230, 'ASSAULT WITH DEADLY WEAPON, AGGRAVATED ASSAULT', 50, 'M', 'STREET', 'AA', '200 N AVENUE 25', 34.04, -118.24)
    (200104138, '01-02-2020', '01-02-2020', 'Central', 230, 'ASSAULT WITH DEADLY WEAPON, AGGRAVATED ASSAULT', 40, 'M', 'OTHER BUSINESS', 'IC', '500 SAN JULIAN ST', 34.06, -118.24)
    (200104139, '01-02-2020', '01-02-2020', 'Central', 888, 'TRESPASSING', 34, 'M', 'RESTAURANT/FAST FOOD', 'IC', '43RD ST', 34.05, -118.26)
    (200104141, '01-02-2020', '01-02-2020', 'Central', 624, 'BATTERY - SIMPLE ASSAULT', 45, 'M', 'OTHER BUSINESS', 'IC', '100 PASEO DE LA PLAZA', 34.05, -118.26)
    (200104150, '01-03-2020', '01-02-2020', 'Central', 624, 'BATTERY - SIMPLE ASSAULT', 62, 'M', 'SIDEWALK', 'IC', '500 S SAN PEDRO ST', 34.04, -118.24)
    (200516527, '11-12-2020', '11-12-2020', 'Harbor', 510, 'VEHICLE - STOLEN', 0, '', 'DRIVEWAY', 'IC', '1300 S LOS ANGELES ST', 33.81, -118.31)
    (200104187, '01-03-2020', '01-01-2020', 'Central', 442, 'SHOPLIFTING - PETTY THEFT ($950 & UNDER)', 20, 'F', 'DEPARTMENT STORE', 'IC', '800 S FIGUEROA ST', 34.05, -118.26)
    (211422362, '12-02-2021', '12-02-2020', 'Pacific', 354, 'THEFT OF IDENTITY', 31, 'F', 'SINGLE FAMILY DWELLING', 'IC', '800 N ALAMEDA ST', 34.01, -118.45)
    (200104192, '01-03-2020', '01-03-2020', 'Central', 745, 'VANDALISM - MISDEAMEANOR ($399 OR UNDER)', 0, 'X', 'SIDEWALK', 'IC', 'JESSE ST', 34.05, -118.24)
    (200104201, '01-03-2020', '01-01-2020', 'Central', 330, 'BURGLARY FROM VEHICLE', 51, 'M', 'STREET', 'IC', '700 W 7TH ST', 34.05, -118.25)
    (200104204, '01-03-2020', '01-02-2020', 'Central', 440, 'THEFT PLAIN - PETTY ($950 & UNDER)', 23, 'M', 'STREET', 'IC', '500 S SAN PEDRO ST', 34.04, -118.25)
    (200104205, '01-03-2020', '01-03-2020', 'Central', 440, 'THEFT PLAIN - PETTY ($950 & UNDER)', 29, 'M', 'STREET', 'IC', '700 W 7TH ST', 34.05, -118.24)
    (200104208, '01-03-2020', '01-03-2020', 'Central', 745, 'VANDALISM - MISDEAMEANOR ($399 OR UNDER)', 58, 'M', 'MULTI-UNIT DWELLING (APARTMENT, DUPLEX, ETC)', 'AO', '100 E 4TH ST', 34.04, -118.27)
    (200104209, '01-03-2020', '01-03-2020', 'Central', 624, 'BATTERY - SIMPLE ASSAULT', 24, 'M', 'SIDEWALK', 'IC', '600 S SPRING ST', 34.05, -118.26)
    (200104221, '01-03-2020', '01-03-2020', 'Central', 761, 'BRANDISH WEAPON', 51, 'F', 'MULTI-UNIT DWELLING (APARTMENT, DUPLEX, ETC)', 'IC', '700 S FLOWER ST', 34.04, -118.25)
    (200104222, '01-03-2020', '01-03-2020', 'Central', 740, 'VANDALISM - FELONY ($400 & OVER, ALL CHURCH VANDALISMS)', 41, 'F', 'MULTI-UNIT DWELLING (APARTMENT, DUPLEX, ETC)', 'AA', '800 N ALAMEDA ST', 34.05, -118.24)
    (200104223, '01-03-2020', '01-03-2020', 'Central', 745, 'VANDALISM - MISDEAMEANOR ($399 OR UNDER)', 32, 'M', 'VEHICLE, PASSENGER/TRUCK', 'IC', '600 S SPRING ST', 34.05, -118.25)
    (200104224, '01-03-2020', '01-03-2020', 'Central', 442, 'SHOPLIFTING - PETTY THEFT ($950 & UNDER)', 23, 'M', 'OTHER STORE', 'IC', '7TH', 34.05, -118.26)
    (200104227, '01-04-2020', '01-03-2020', 'Central', 442, 'SHOPLIFTING - PETTY THEFT ($950 & UNDER)', 35, 'M', 'OTHER STORE', 'IC', '900 NEW DEPOT ST', 34.05, -118.26)
    (200104228, '01-04-2020', '01-03-2020', 'Central', 210, 'ROBBERY', 28, 'M', 'STREET', 'IC', '400 CASANOVA ST', 34.04, -118.24)
    (200104230, '01-04-2020', '01-03-2020', 'Central', 420, 'THEFT FROM MOTOR VEHICLE - PETTY ($950 & UNDER)', 0, '', 'STREET', 'IC', '600 S GRAND AV', 34.05, -118.26)
    (200104231, '01-03-2020', '01-03-2020', 'Central', 230, 'ASSAULT WITH DEADLY WEAPON, AGGRAVATED ASSAULT', 58, 'M', 'STREET', 'IC', '500 S SPRING ST', 34.04, -118.24)
    (200104233, '01-03-2020', '01-03-2020', 'Central', 341, 'THEFT-GRAND ($950.01 & OVER)EXCPT,GUNS,FOWL,LIVESTK,PROD', 57, 'M', 'MULTI-UNIT DWELLING (APARTMENT, DUPLEX, ETC)', 'IC', '600 WALL ST', 34.05, -118.25)
    (200104234, '01-04-2020', '01-03-2020', 'Central', 440, 'THEFT PLAIN - PETTY ($950 & UNDER)', 27, 'F', 'RESTAURANT/FAST FOOD', 'IC', '900 N BROADWAY', 34.05, -118.24)
    (200104235, '01-04-2020', '01-03-2020', 'Central', 330, 'BURGLARY FROM VEHICLE', 30, 'F', 'STREET', 'IC', '5TH ST', 34.04, -118.23)
    (200104236, '01-03-2020', '01-03-2020', 'Central', 330, 'BURGLARY FROM VEHICLE', 30, 'M', 'STREET', 'IC', '700 S OLIVE ST', 34.05, -118.26)
    (200104237, '01-04-2020', '01-04-2020', 'Central', 330, 'BURGLARY FROM VEHICLE', 31, 'M', 'STREET', 'IC', '100 N LOS ANGELES ST', 34.04, -118.26)
    (200104238, '01-03-2020', '01-03-2020', 'Central', 330, 'BURGLARY FROM VEHICLE', 0, 'X', 'PARKING LOT', 'IC', '6TH ST', 34.04, -118.26)
    (200409682, '06-10-2020', '06-10-2020', 'Hollenbeck', 210, 'ROBBERY', 24, 'F', 'SINGLE FAMILY DWELLING', 'AA', '900 S LOS ANGELES ST', 34.08, -118.22)
    (200104244, '01-04-2020', '01-04-2020', 'Central', 624, 'BATTERY - SIMPLE ASSAULT', 48, 'F', 'SIDEWALK', 'IC', '800 N ALAMEDA ST', 34.04, -118.25)
    (200306227, '02-07-2020', '02-06-2020', 'Southwest', 510, 'VEHICLE - STOLEN', 0, '', 'STREET', 'IC', '800 N ALAMEDA ST', 34.01, -118.3)
    (200104268, '01-04-2020', '01-04-2020', 'Central', 624, 'BATTERY - SIMPLE ASSAULT', 40, 'F', 'STREET', 'IC', '800 N ALAMEDA ST', 34.06, -118.24)
    (200104269, '01-04-2020', '01-04-2020', 'Central', 624, 'BATTERY - SIMPLE ASSAULT', 57, 'F', 'SIDEWALK', 'IC', '200 N SOTO ST', 34.04, -118.25)
    (200104270, '01-04-2020', '01-04-2020', 'Central', 330, 'BURGLARY FROM VEHICLE', 32, 'M', 'PARKING LOT', 'IC', 'HILL', 34.04, -118.26)
    (200816200, '11-08-2020', '11-07-2020', 'West LA', 886, 'DISTURBING THE PEACE', 58, 'M', 'MULTI-UNIT DWELLING (APARTMENT, DUPLEX, ETC)', 'AO', '700 S BROADWAY', 34.06, -118.38)
    (200104275, '01-04-2020', '01-04-2020', 'Central', 442, 'SHOPLIFTING - PETTY THEFT ($950 & UNDER)', 0, 'X', 'MARKET', 'IC', '1800 S MAIN ST', 34.05, -118.26)
    (200104276, '01-04-2020', '01-02-2020', 'Central', 440, 'THEFT PLAIN - PETTY ($950 & UNDER)', 18, 'M', 'LA UNION STATION (NOT LINE SPECIFIC)', 'IC', '700 S FIGUEROA ST', 34.06, -118.24)
    (200104277, '01-05-2020', '01-04-2020', 'Central', 330, 'BURGLARY FROM VEHICLE', 25, 'M', 'STREET', 'IC', 'SPRING ST', 34.04, -118.23)
    (200104279, '01-04-2020', '01-04-2020', 'Central', 442, 'SHOPLIFTING - PETTY THEFT ($950 & UNDER)', 0, 'X', 'DEPARTMENT STORE', 'IC', '6TH ST', 34.05, -118.26)
    (200104281, '01-04-2020', '01-04-2020', 'Central', 440, 'THEFT PLAIN - PETTY ($950 & UNDER)', 37, 'F', 'MISSIONS/SHELTERS', 'IC', '2200 SAN YSIDRO DR', 34.04, -118.25)
    (200104283, '01-04-2020', '01-04-2020', 'Central', 442, 'SHOPLIFTING - PETTY THEFT ($950 & UNDER)', 0, 'X', 'DEPARTMENT STORE', 'IC', '600 N BROADWAY', 34.05, -118.26)
    (200104284, '01-04-2020', '01-04-2020', 'Central', 888, 'TRESPASSING', 67, 'M', 'MULTI-UNIT DWELLING (APARTMENT, DUPLEX, ETC)', 'IC', '8TH', 34.05, -118.25)
    (200104285, '01-05-2020', '01-05-2020', 'Central', 624, 'BATTERY - SIMPLE ASSAULT', 26, 'M', 'OTHER BUSINESS', 'IC', '800 N ALAMEDA ST', 34.05, -118.25)
    (200104286, '01-04-2020', '01-04-2020', 'Central', 330, 'BURGLARY FROM VEHICLE', 47, 'M', 'GARAGE/CARPORT', 'IC', '2000 E 7TH ST', 34.05, -118.26)
    (200104287, '01-04-2020', '01-04-2020', 'Central', 624, 'BATTERY - SIMPLE ASSAULT', 21, 'F', 'LA UNION STATION (NOT LINE SPECIFIC)', 'IC', '700 S FLOWER ST', 34.06, -118.24)
    (200104289, '01-05-2020', '01-03-2020', 'Central', 440, 'THEFT PLAIN - PETTY ($950 & UNDER)', 26, 'F', 'NIGHT CLUB (OPEN EVENINGS ONLY)', 'IC', '4TH', 34.05, -118.25)
    (200104291, '01-05-2020', '01-04-2020', 'Central', 210, 'ROBBERY', 64, 'M', 'SIDEWALK', 'IC', 'W 5TH ST', 34.04, -118.25)
    (200104292, '01-05-2020', '01-04-2020', 'Central', 440, 'THEFT PLAIN - PETTY ($950 & UNDER)', 26, 'F', 'MULTI-UNIT DWELLING (APARTMENT, DUPLEX, ETC)', 'IC', '800 S HILL ST', 34.07, -118.25)
    (200104293, '01-05-2020', '01-03-2020', 'Central', 420, 'THEFT FROM MOTOR VEHICLE - PETTY ($950 & UNDER)', 31, 'F', 'PARKING UNDERGROUND/BUILDING', 'IC', '6TH', 34.07, -118.23)
    (200104300, '01-05-2020', '01-04-2020', 'Central', 740, 'VANDALISM - FELONY ($400 & OVER, ALL CHURCH VANDALISMS)', 39, 'M', 'VEHICLE, PASSENGER/TRUCK', 'IC', '7TH', 34.05, -118.26)
    (200104302, '01-01-2020', '01-01-2020', 'Central', 440, 'THEFT PLAIN - PETTY ($950 & UNDER)', 25, 'F', 'BAR/COCKTAIL/NIGHTCLUB', 'IC', '100 S FIGUEROA ST', 34.05, -118.25)
    (200104303, '01-05-2020', '01-04-2020', 'Central', 510, 'VEHICLE - STOLEN', 0, '', 'PARKING LOT', 'IC', '600 S FIGUEROA ST', 34.04, -118.25)
    (200104310, '01-05-2020', '01-05-2020', 'Central', 624, 'BATTERY - SIMPLE ASSAULT', 28, 'M', 'SIDEWALK', 'IC', '100 E 17TH ST', 34.06, -118.24)
    (200104313, '01-05-2020', '01-04-2020', 'Central', 341, 'THEFT-GRAND ($950.01 & OVER)EXCPT,GUNS,FOWL,LIVESTK,PROD', 75, 'M', 'SIDEWALK', 'IC', '6100 DELPHI ST', 34.04, -118.25)
    (200104316, '01-05-2020', '01-04-2020', 'Central', 930, 'CRIMINAL THREATS - NO WEAPON DISPLAYED', 32, 'F', 'MULTI-UNIT DWELLING (APARTMENT, DUPLEX, ETC)', 'IC', '400 S BROADWAY', 34.05, -118.26)
    (200104319, '01-04-2020', '01-04-2020', 'Central', 623, 'BATTERY POLICE (SIMPLE)', 0, 'X', 'DETENTION/JAIL FACILITY', 'IC', '700 S FIGUEROA ST', 34.05, -118.24)
    (200104320, '01-05-2020', '01-04-2020', 'Central', 330, 'BURGLARY FROM VEHICLE', 0, 'M', 'STREET', 'IC', '8TH', 34.04, -118.25)
    (200104321, '01-06-2020', '01-05-2020', 'Central', 330, 'BURGLARY FROM VEHICLE', 30, 'F', 'STREET', 'IC', '14TH', 34.04, -118.25)
    (200104323, '01-05-2020', '01-03-2020', 'Central', 420, 'THEFT FROM MOTOR VEHICLE - PETTY ($950 & UNDER)', 28, 'M', 'STREET', 'IC', '7TH ST', 34.04, -118.25)
    (200104326, '01-05-2020', '01-05-2020', 'Central', 740, 'VANDALISM - FELONY ($400 & OVER, ALL CHURCH VANDALISMS)', 56, 'M', 'STREET', 'AA', '300 S BROADWAY', 34.04, -118.27)
    (200104327, '01-05-2020', '01-05-2020', 'Central', 210, 'ROBBERY', 0, 'X', 'LA UNION STATION (NOT LINE SPECIFIC)', 'AA', '300 S BROADWAY', 34.06, -118.24)
    (200104328, '01-05-2020', '01-05-2020', 'Central', 350, 'THEFT, PERSON', 35, 'F', 'SIDEWALK', 'IC', '4TH ST', 34.05, -118.25)
    (200104329, '01-05-2020', '01-05-2020', 'Central', 421, 'THEFT FROM MOTOR VEHICLE - ATTEMPT', 28, 'F', 'SIDEWALK', 'IC', '12TH', 34.05, -118.25)
    (200104330, '01-06-2020', '01-05-2020', 'Central', 888, 'TRESPASSING', 19, 'M', 'LA UNION STATION (NOT LINE SPECIFIC)', 'IC', '8TH ST', 34.06, -118.24)
    (200104331, '01-05-2020', '01-05-2020', 'Central', 624, 'BATTERY - SIMPLE ASSAULT', 43, 'F', 'OTHER PREMISE', 'IC', '11TH ST', 34.04, -118.24)
    (200104333, '01-06-2020', '01-06-2020', 'Central', 888, 'TRESPASSING', 0, 'X', 'LA UNION STATION (NOT LINE SPECIFIC)', 'IC', '300 E 5TH ST', 34.06, -118.24)
    (200405489, '02-07-2020', '02-06-2020', 'Hollenbeck', 946, 'OTHER MISCELLANEOUS CRIME', 12, 'F', 'SINGLE FAMILY DWELLING', 'AO', '6TH', 34.04, -118.21)
    (200104336, '01-06-2020', '01-05-2020', 'Central', 647, 'THROWING OBJECT AT MOVING VEHICLE', 43, 'M', 'STREET', 'IC', '1ST ST', 34.04, -118.26)
    (200104337, '01-06-2020', '01-06-2020', 'Central', 440, 'THEFT PLAIN - PETTY ($950 & UNDER)', 59, 'M', 'SIDEWALK', 'IC', '200 W WASHINGTON BL', 34.05, -118.25)
    (200104339, '01-05-2020', '01-05-2020', 'Central', 745, 'VANDALISM - MISDEAMEANOR ($399 OR UNDER)', 34, 'F', 'VEHICLE, PASSENGER/TRUCK', 'IC', '800 JAMES M WOOD BL', 34.04, -118.26)
    (200104340, '01-06-2020', '01-05-2020', 'Central', 310, 'BURGLARY', 38, 'M', 'MULTI-UNIT DWELLING (APARTMENT, DUPLEX, ETC)', 'IC', '400 W 7TH ST', 34.03, -118.26)
    (200104351, '01-01-2020', '01-01-2020', 'Central', 330, 'BURGLARY FROM VEHICLE', 37, 'M', 'PARKING LOT', 'IC', '1100 S FIGUEROA ST', 34.05, -118.26)
    (200104352, '01-06-2020', '01-05-2020', 'Central', 420, 'THEFT FROM MOTOR VEHICLE - PETTY ($950 & UNDER)', 0, '', 'STREET', 'IC', '900 W 8TH ST', 34.05, -118.25)
    (200104360, '01-06-2020', '01-06-2020', 'Central', 230, 'ASSAULT WITH DEADLY WEAPON, AGGRAVATED ASSAULT', 61, 'X', 'SIDEWALK', 'AA', '700 S FLOWER ST', 34.05, -118.25)
    (210804296, '01-08-2020', '01-04-2020', 'West LA', 940, 'EXTORTION', 49, 'M', 'SINGLE FAMILY DWELLING', 'AO', '400 SEATON ST', 34.11, -118.42)
    (200104369, '01-06-2020', '01-06-2020', 'Central', 230, 'ASSAULT WITH DEADLY WEAPON, AGGRAVATED ASSAULT', 22, 'M', 'STREET', 'IC', '1000 N BROADWAY', 34.05, -118.24)
    (200104372, '01-06-2020', '01-06-2020', 'Central', 330, 'BURGLARY FROM VEHICLE', 43, 'F', 'PARKING UNDERGROUND/BUILDING', 'IC', '1300 MAGDALENA ST', 34.06, -118.24)
    (200104377, '01-06-2020', '01-05-2020', 'Central', 624, 'BATTERY - SIMPLE ASSAULT', 71, 'M', 'STREET', 'IC', '00 GATEWAY PLAZA DR', 34.04, -118.25)
    (200104379, '01-06-2020', '01-06-2020', 'Central', 624, 'BATTERY - SIMPLE ASSAULT', 71, 'M', 'LA UNION STATION (NOT LINE SPECIFIC)', 'IC', '600 WILSHIRE BL', 34.06, -118.24)
    (200104381, '01-06-2020', '01-06-2020', 'Central', 510, 'VEHICLE - STOLEN', 0, '', 'PARKING LOT', 'IC', '1ST', 34.04, -118.23)
    (200104382, '01-06-2020', '01-06-2020', 'Central', 442, 'SHOPLIFTING - PETTY THEFT ($950 & UNDER)', 55, 'M', 'CLOTHING STORE', 'IC', '500 N FIGUEROA ST', 34.05, -118.26)
    (200104385, '01-06-2020', '01-06-2020', 'Central', 330, 'BURGLARY FROM VEHICLE', 19, 'F', 'STREET', 'IC', '5TH ST', 34.04, -118.24)
    (200104389, '01-02-2020', '01-01-2020', 'Central', 330, 'BURGLARY FROM VEHICLE', 68, 'F', 'STREET', 'IC', 'GEORGIA ST', 34.05, -118.25)
    (200104390, '01-03-2020', '01-03-2020', 'Central', 354, 'THEFT OF IDENTITY', 38, 'F', 'BANK', 'IC', '1100 S FIGUEROA ST', 34.05, -118.26)
    (200104392, '01-06-2020', '01-03-2020', 'Central', 480, 'BIKE - STOLEN', 48, 'M', 'MTA BUS', 'IC', '700 W 7TH ST', 34.05, -118.25)
    (200104393, '01-06-2020', '01-06-2020', 'Central', 624, 'BATTERY - SIMPLE ASSAULT', 69, 'F', 'SIDEWALK', 'IC', 'ALPINE ST', 34.04, -118.25)
    (200104406, '01-06-2020', '01-04-2020', 'Central', 330, 'BURGLARY FROM VEHICLE', 50, 'F', 'PARKING LOT', 'IC', '100 E 5TH ST', 34.06, -118.25)
    (200104408, '01-06-2020', '01-06-2020', 'Central', 624, 'BATTERY - SIMPLE ASSAULT', 13, 'M', 'MTA - BLUE LINE - 7TH AND METRO CENTER', 'IC', '300 E 5TH ST', 34.05, -118.26)
    (200104410, '01-06-2020', '01-06-2020', 'Central', 662, 'BUNCO, GRAND THEFT', 61, 'M', 'OTHER BUSINESS', 'IC', '500 WALL ST', 34.03, -118.26)
    (200104411, '01-07-2020', '01-06-2020', 'Central', 510, 'VEHICLE - STOLEN', 0, '', 'STREET', 'IC', 'PICO BL', 34.04, -118.26)
    (201106871, '03-04-2020', '03-02-2020', 'Northeast', 745, 'VANDALISM - MISDEAMEANOR ($399 OR UNDER)', 50, 'M', 'STREET', 'IC', '1100 S HOPE ST', 34.12, -118.19)
    (200104414, '01-06-2020', '01-05-2020', 'Central', 330, 'BURGLARY FROM VEHICLE', 26, 'M', 'PARKING LOT', 'IC', '400 S HEWITT ST', 34.05, -118.26)
    (200104416, '01-06-2020', '01-06-2020', 'Central', 930, 'CRIMINAL THREATS - NO WEAPON DISPLAYED', 26, 'F', 'DRUG STORE', 'IC', '4TH ST', 34.05, -118.25)
    (200104419, '01-06-2020', '01-06-2020', 'Central', 440, 'THEFT PLAIN - PETTY ($950 & UNDER)', 45, 'M', 'DEPARTMENT STORE', 'IC', '600 S SAN PEDRO ST', 34.05, -118.26)
    (200104420, '01-05-2020', '01-05-2020', 'Central', 745, 'VANDALISM - MISDEAMEANOR ($399 OR UNDER)', 36, 'F', 'VEHICLE, PASSENGER/TRUCK', 'IC', '1400 S FIGUEROA ST', 34.05, -118.26)
    (200104422, '01-06-2020', '01-06-2020', 'Central', 330, 'BURGLARY FROM VEHICLE', 24, 'M', 'STREET', 'IC', '300 E 5TH ST', 34.04, -118.27)
    (200104429, '01-07-2020', '01-06-2020', 'Central', 888, 'TRESPASSING', 0, 'M', 'OTHER BUSINESS', 'IC', '700 S FIGUEROA ST', 34.06, -118.24)
    (200104430, '01-02-2020', '01-02-2020', 'Central', 480, 'BIKE - STOLEN', 50, 'M', 'SIDEWALK', 'IC', 'VENICE', 34.05, -118.26)
    (200104431, '01-02-2020', '01-02-2020', 'Central', 330, 'BURGLARY FROM VEHICLE', 25, 'F', 'PARKING LOT', 'IC', '200 S SAN PEDRO ST', 34.05, -118.25)
    (200104432, '01-03-2020', '01-02-2020', 'Central', 440, 'THEFT PLAIN - PETTY ($950 & UNDER)', 27, 'M', 'MARKET', 'IC', '800 N HILL ST', 34.05, -118.25)
    (200104435, '01-02-2020', '01-02-2020', 'Central', 330, 'BURGLARY FROM VEHICLE', 33, 'M', 'STREET', 'IC', '700 S LOS ANGELES ST', 34.04, -118.24)
    (200104440, '01-04-2020', '01-04-2020', 'Central', 330, 'BURGLARY FROM VEHICLE', 53, 'M', 'PARKING LOT', 'IC', '800 S HILL ST', 34.04, -118.27)
    (200104443, '01-04-2020', '01-03-2020', 'Central', 330, 'BURGLARY FROM VEHICLE', 38, 'F', 'STREET', 'IC', '800 N ALAMEDA ST', 34.04, -118.25)
    (200104444, '01-05-2020', '01-05-2020', 'Central', 330, 'BURGLARY FROM VEHICLE', 23, 'M', 'PARKING LOT', 'IC', '500 S BROADWAY', 34.04, -118.26)
    (200104449, '01-07-2020', '01-07-2020', 'Central', 624, 'BATTERY - SIMPLE ASSAULT', 74, 'M', 'SIDEWALK', 'IC', '600 S FIGUEROA ST', 34.05, -118.24)
    (200104450, '01-07-2020', '01-07-2020', 'Central', 740, 'VANDALISM - FELONY ($400 & OVER, ALL CHURCH VANDALISMS)', 0, 'X', 'STREET', 'IC', '400 SAVOY ST', 34.04, -118.25)
    (200104451, '01-07-2020', '01-07-2020', 'Central', 740, 'VANDALISM - FELONY ($400 & OVER, ALL CHURCH VANDALISMS)', 0, 'X', 'SIDEWALK', 'IC', '800 N ALAMEDA ST', 34.05, -118.24)
    (200104452, '01-07-2020', '01-07-2020', 'Central', 624, 'BATTERY - SIMPLE ASSAULT', 23, 'M', 'PARKING LOT', 'IC', '800 N ALAMEDA ST', 34.04, -118.27)
    (200104455, '01-06-2020', '01-06-2020', 'Central', 330, 'BURGLARY FROM VEHICLE', 26, 'F', 'STREET', 'IC', '900 S HILL ST', 34.05, -118.26)
    (200104456, '01-06-2020', '01-03-2020', 'Central', 341, 'THEFT-GRAND ($950.01 & OVER)EXCPT,GUNS,FOWL,LIVESTK,PROD', 0, 'X', 'OTHER/OUTSIDE', 'IC', 'W 17TH ST', 34.05, -118.26)
    (200104459, '01-03-2020', '01-03-2020', 'Central', 330, 'BURGLARY FROM VEHICLE', 23, 'M', 'STAPLES CENTER *', 'IC', '700 S GRAND AV', 34.04, -118.27)
    (200104462, '01-07-2020', '01-06-2020', 'Central', 480, 'BIKE - STOLEN', 57, 'M', 'PARKING UNDERGROUND/BUILDING', 'IC', '200 S SAN PEDRO ST', 34.05, -118.26)
    (200104470, '01-07-2020', '01-06-2020', 'Central', 440, 'THEFT PLAIN - PETTY ($950 & UNDER)', 25, 'F', 'OTHER PREMISE', 'IC', '6500 YUCCA ST', 34.05, -118.24)
    (200104474, '01-07-2020', '01-06-2020', 'Central', 888, 'TRESPASSING', 34, 'F', 'DEPARTMENT STORE', 'IC', '3900 DENKER AV', 34.05, -118.26)
    (200104475, '01-07-2020', '01-06-2020', 'Central', 740, 'VANDALISM - FELONY ($400 & OVER, ALL CHURCH VANDALISMS)', 35, 'M', 'STREET', 'IC', '700 N MAIN ST', 34.04, -118.24)
    (200104476, '01-07-2020', '01-06-2020', 'Central', 330, 'BURGLARY FROM VEHICLE', 38, 'M', 'PARKING LOT', 'IC', '700 WILSHIRE BL', 34.07, -118.23)
    (200104477, '01-07-2020', '01-06-2020', 'Central', 930, 'CRIMINAL THREATS - NO WEAPON DISPLAYED', 29, 'F', 'SIDEWALK', 'IC', '400 W 8TH ST', 34.06, -118.23)
    (200104488, '01-07-2020', '01-07-2020', 'Central', 442, 'SHOPLIFTING - PETTY THEFT ($950 & UNDER)', 24, 'M', "COFFEE SHOP (STARBUCKS, COFFEE BEAN, PEET'S, ETC.)", 'IC', '700 W 7TH ST', 34.06, -118.23)
    (200104489, '01-07-2020', '01-07-2020', 'Central', 624, 'BATTERY - SIMPLE ASSAULT', 26, 'F', 'STREET', 'IC', '6TH', 34.05, -118.26)
    (200104498, '01-07-2020', '01-07-2020', 'Central', 220, 'ATTEMPTED ROBBERY', 56, 'M', 'SIDEWALK', 'IC', '1000 WILSHIRE BL', 34.05, -118.24)
    (200104499, '01-07-2020', '01-06-2020', 'Central', 330, 'BURGLARY FROM VEHICLE', 26, 'M', 'STREET', 'IC', 'E 8TH ST', 34.06, -118.25)
    (200104500, '01-07-2020', '01-07-2020', 'Central', 625, 'OTHER ASSAULT', 47, 'M', 'OTHER BUSINESS', 'IC', '8700 SUNLAND BL', 34.05, -118.25)
    (200104501, '01-08-2020', '01-08-2020', 'Central', 350, 'THEFT, PERSON', 29, 'F', 'PARKING UNDERGROUND/BUILDING', 'AA', 'ALPINE ST', 34.05, -118.27)
    (200104503, '01-08-2020', '01-08-2020', 'Central', 755, 'BOMB SCARE', 29, 'M', 'STAPLES CENTER *', 'IC', '6TH', 34.04, -118.27)
    (200104505, '01-07-2020', '01-07-2020', 'Central', 442, 'SHOPLIFTING - PETTY THEFT ($950 & UNDER)', 0, 'X', 'DEPARTMENT STORE', 'IC', '300 E 2ND ST', 34.05, -118.26)
    (200104513, '01-08-2020', '01-07-2020', 'Central', 510, 'VEHICLE - STOLEN', 0, '', 'STREET', 'IC', '1300 S HOPE ST', 34.07, -118.25)
    (200104522, '01-08-2020', '01-07-2020', 'Central', 330, 'BURGLARY FROM VEHICLE', 32, 'M', 'PARKING UNDERGROUND/BUILDING', 'IC', '700 CENTER ST', 34.05, -118.26)
    (200104524, '01-08-2020', '01-08-2020', 'Central', 624, 'BATTERY - SIMPLE ASSAULT', 30, 'M', 'SIDEWALK', 'IC', '300 E 2ND ST', 34.04, -118.26)
    (200104526, '01-08-2020', '01-07-2020', 'Central', 624, 'BATTERY - SIMPLE ASSAULT', 62, 'F', 'MULTI-UNIT DWELLING (APARTMENT, DUPLEX, ETC)', 'IC', '500 S MAIN ST', 34.05, -118.25)
    (200104527, '01-08-2020', '01-06-2020', 'Central', 440, 'THEFT PLAIN - PETTY ($950 & UNDER)', 71, 'M', 'MISSIONS/SHELTERS', 'IC', 'FACTORY PL', 34.05, -118.24)
    (200104534, '01-08-2020', '01-08-2020', 'Central', 624, 'BATTERY - SIMPLE ASSAULT', 53, 'M', 'SIDEWALK', 'IC', '400 S ALAMEDA ST', 34.04, -118.25)
    (200104545, '01-07-2020', '01-02-2020', 'Central', 341, 'THEFT-GRAND ($950.01 & OVER)EXCPT,GUNS,FOWL,LIVESTK,PROD', 31, 'M', 'VEHICLE, PASSENGER/TRUCK', 'IC', '5TH ST', 34.04, -118.26)
    (200104547, '01-08-2020', '01-07-2020', 'Central', 341, 'THEFT-GRAND ($950.01 & OVER)EXCPT,GUNS,FOWL,LIVESTK,PROD', 0, 'M', 'CONSTRUCTION SITE', 'IC', '600 CERES AV', 34.04, -118.26)
    (200104548, '01-07-2020', '01-06-2020', 'Central', 440, 'THEFT PLAIN - PETTY ($950 & UNDER)', 49, 'M', 'RESTAURANT/FAST FOOD', 'IC', '800 S OLIVE ST', 34.04, -118.24)
    (200104549, '01-08-2020', '01-06-2020', 'Central', 440, 'THEFT PLAIN - PETTY ($950 & UNDER)', 38, 'M', 'STREET', 'IC', '300 S BROADWAY', 34.05, -118.24)
    (200104550, '01-08-2020', '01-08-2020', 'Central', 740, 'VANDALISM - FELONY ($400 & OVER, ALL CHURCH VANDALISMS)', 55, 'M', 'MISSIONS/SHELTERS', 'IC', '4TH ST', 34.04, -118.25)
    (200104551, '01-08-2020', '01-08-2020', 'Central', 761, 'BRANDISH WEAPON', 43, 'M', 'CONSTRUCTION SITE', 'IC', '2ND ST', 34.04, -118.27)
    (211613998, '11-08-2021', '11-01-2020', 'Foothill', 354, 'THEFT OF IDENTITY', 64, 'F', 'SINGLE FAMILY DWELLING', 'IC', 'WESTLAKE', 34.27, -118.36)
    (200104556, '01-08-2020', '01-08-2020', 'Central', 440, 'THEFT PLAIN - PETTY ($950 & UNDER)', 56, 'M', 'SIDEWALK', 'IC', 'HEWITT', 34.05, -118.24)
    (200104573, '01-08-2020', '01-08-2020', 'Central', 330, 'BURGLARY FROM VEHICLE', 30, 'M', 'STREET', 'IC', 'HEWITT', 34.05, -118.24)
    (200104576, '01-08-2020', '01-08-2020', 'Central', 440, 'THEFT PLAIN - PETTY ($950 & UNDER)', 35, 'M', 'OTHER BUSINESS', 'IC', '800 W OLYMPIC BL', 34.05, -118.26)
    (200104577, '01-08-2020', '01-08-2020', 'Central', 510, 'VEHICLE - STOLEN', 0, '', 'STREET', 'IC', '1800 S FLOWER ST', 34.04, -118.27)
    (200104578, '01-09-2020', '01-07-2020', 'Central', 888, 'TRESPASSING', 36, 'M', 'MULTI-UNIT DWELLING (APARTMENT, DUPLEX, ETC)', 'IC', '700 S MAIN ST', 34.05, -118.24)
    (200104579, '01-09-2020', '01-07-2020', 'Central', 310, 'BURGLARY', 25, 'F', 'MEDICAL/DENTAL OFFICES', 'IC', 'OLIVE', 34.06, -118.24)
    (200104580, '01-09-2020', '01-08-2020', 'Central', 480, 'BIKE - STOLEN', 67, 'M', 'RESTAURANT/FAST FOOD', 'IC', '500 W 6TH ST', 34.05, -118.26)
    (200104582, '01-09-2020', '01-06-2020', 'Central', 341, 'THEFT-GRAND ($950.01 & OVER)EXCPT,GUNS,FOWL,LIVESTK,PROD', 37, 'M', 'SIDEWALK', 'IC', '700 N ALAMEDA ST', 34.04, -118.25)
    (200104584, '01-08-2020', '01-07-2020', 'Central', 662, 'BUNCO, GRAND THEFT', 40, 'M', 'MULTI-UNIT DWELLING (APARTMENT, DUPLEX, ETC)', 'IC', '600 E 5TH ST', 34.05, -118.26)
    (200104588, '01-09-2020', '01-09-2020', 'Central', 440, 'THEFT PLAIN - PETTY ($950 & UNDER)', 59, 'F', 'LA UNION STATION (NOT LINE SPECIFIC)', 'IC', '500 CERES AV', 34.06, -118.24)
    (200104590, '01-08-2020', '01-08-2020', 'Central', 442, 'SHOPLIFTING - PETTY THEFT ($950 & UNDER)', 34, 'M', 'DRUG STORE', 'IC', 'LOS ANGELES', 34.05, -118.25)
    (200104594, '01-08-2020', '01-08-2020', 'Central', 624, 'BATTERY - SIMPLE ASSAULT', 20, 'M', 'MTA - RED LINE - 7TH AND METRO CENTER', 'IC', '500 S SAN PEDRO ST', 34.05, -118.26)
    (200104598, '01-09-2020', '01-07-2020', 'Central', 745, 'VANDALISM - MISDEAMEANOR ($399 OR UNDER)', 69, 'F', 'SINGLE FAMILY DWELLING', 'IC', '200 S SAN PEDRO ST', 34.07, -118.23)
    (200104603, '01-09-2020', '01-09-2020', 'Central', 480, 'BIKE - STOLEN', 0, 'X', 'MTA - RED LINE - UNION STATION', 'AA', '500 S MAIN ST', 34.06, -118.24)
    (200104609, '01-09-2020', '01-07-2020', 'Central', 220, 'ATTEMPTED ROBBERY', 58, 'F', 'MTA - RED LINE - UNION STATION', 'IC', '400 CASANOVA ST', 34.06, -118.24)
    (200104613, '01-08-2020', '01-06-2020', 'Central', 330, 'BURGLARY FROM VEHICLE', 33, 'F', 'PARKING UNDERGROUND/BUILDING', 'IC', '1600 SANTEE ST', 34.04, -118.26)
    (200104616, '01-07-2020', '01-07-2020', 'Central', 330, 'BURGLARY FROM VEHICLE', 28, 'F', 'STREET', 'IC', '600 N FIGUEROA ST', 34.03, -118.27)
    (200104617, '01-09-2020', '01-01-2020', 'Central', 330, 'BURGLARY FROM VEHICLE', 31, 'M', 'GARAGE/CARPORT', 'IC', '1000 S FLOWER ST', 34.05, -118.26)
    (200104619, '01-08-2020', '01-05-2020', 'Central', 341, 'THEFT-GRAND ($950.01 & OVER)EXCPT,GUNS,FOWL,LIVESTK,PROD', 38, 'M', 'SIDEWALK', 'IC', 'CESAR E CHAVEZ', 34.05, -118.24)
    (200604186, '01-05-2020', '01-05-2020', 'Hollywood', 649, 'DOCUMENT FORGERY / STOLEN FELONY', 0, 'X', 'STREET', 'AA', '300 E 5TH ST', 34.1, -118.33)
    (200610130, '05-11-2020', '05-11-2020', 'Hollywood', 210, 'ROBBERY', 0, 'X', 'MINI-MART', 'AA', '600 S FIGUEROA ST', 34.1, -118.34)
    (200320020, '11-07-2020', '11-07-2020', 'Southwest', 901, 'VIOLATION OF RESTRAINING ORDER', 25, 'M', 'SINGLE FAMILY DWELLING', 'AO', '500 S HILL ST', 34.02, -118.3)
    (200104657, '01-09-2020', '01-09-2020', 'Central', 624, 'BATTERY - SIMPLE ASSAULT', 34, 'F', 'LIQUOR STORE', 'IC', '5TH', 34.06, -118.24)
    (200104658, '01-09-2020', '01-09-2020', 'Central', 946, 'OTHER MISCELLANEOUS CRIME', 41, 'M', 'PARKING LOT', 'IC', '500 RAMIREZ ST', 34.05, -118.26)
    (200104660, '01-09-2020', '01-08-2020', 'Central', 740, 'VANDALISM - FELONY ($400 & OVER, ALL CHURCH VANDALISMS)', 49, 'F', 'TOBACCO SHOP', 'IC', '800 N ALAMEDA ST', 34.04, -118.26)
    (200104663, '01-09-2020', '01-09-2020', 'Central', 442, 'SHOPLIFTING - PETTY THEFT ($950 & UNDER)', 20, 'F', 'OTHER STORE', 'IC', '800 N ALAMEDA ST', 34.05, -118.26)
    (200104670, '01-10-2020', '01-09-2020', 'Central', 330, 'BURGLARY FROM VEHICLE', 30, 'F', 'STREET', 'IC', '600 W 7TH ST', 34.04, -118.25)
    (200104673, '01-09-2020', '01-01-2020', 'Central', 341, 'THEFT-GRAND ($950.01 & OVER)EXCPT,GUNS,FOWL,LIVESTK,PROD', 27, 'F', 'MULTI-UNIT DWELLING (APARTMENT, DUPLEX, ETC)', 'IC', '900 N BEAUDRY AV', 34.05, -118.26)
    (200104682, '01-09-2020', '01-09-2020', 'Central', 440, 'THEFT PLAIN - PETTY ($950 & UNDER)', 32, 'M', 'HIGH-RISE BUILDING', 'IC', '500 S LOS ANGELES ST', 34.05, -118.26)
    (200104683, '01-10-2020', '01-06-2020', 'Central', 440, 'THEFT PLAIN - PETTY ($950 & UNDER)', 39, 'F', 'MULTI-UNIT DWELLING (APARTMENT, DUPLEX, ETC)', 'IC', '500 S SAN PEDRO ST', 34.04, -118.25)
    (201610902, '07-09-2020', '07-09-2020', 'Foothill', 210, 'ROBBERY', 35, 'F', 'RESTAURANT/FAST FOOD', 'AA', '1100 S FIGUEROA ST', 34.23, -118.37)
    (200104691, '01-09-2020', '01-08-2020', 'Central', 350, 'THEFT, PERSON', 64, 'F', 'STREET', 'IC', '600 N SPRING ST', 34.06, -118.24)
    (200104696, '01-10-2020', '01-10-2020', 'Central', 624, 'BATTERY - SIMPLE ASSAULT', 57, 'M', 'STREET', 'IC', '100 E 5TH ST', 34.04, -118.25)
    (200104697, '01-10-2020', '01-09-2020', 'Central', 330, 'BURGLARY FROM VEHICLE', 34, 'F', 'PARKING LOT', 'IC', '400 COLYTON ST', 34.05, -118.24)
    (200104700, '01-10-2020', '01-08-2020', 'Central', 330, 'BURGLARY FROM VEHICLE', 29, 'M', 'PARKING LOT', 'IC', 'FLOWER', 34.04, -118.26)
    (200104702, '01-10-2020', '01-10-2020', 'Central', 745, 'VANDALISM - MISDEAMEANOR ($399 OR UNDER)', 0, 'X', 'HOSPITAL', 'IC', '600 S SPRING ST', 34.04, -118.27)
    (200104703, '01-01-2020', '01-01-2020', 'Central', 330, 'BURGLARY FROM VEHICLE', 27, 'M', 'PARKING LOT', 'IC', '1100 S FIGUEROA ST', 34.05, -118.23)
    (200104704, '01-09-2020', '01-09-2020', 'Central', 330, 'BURGLARY FROM VEHICLE', 0, 'X', 'PARKING LOT', 'IC', '1200 S MAIN ST', 34.05, -118.24)
    (200104713, '01-10-2020', '01-10-2020', 'Central', 900, 'VIOLATION OF COURT ORDER', 53, 'M', 'MULTI-UNIT DWELLING (APARTMENT, DUPLEX, ETC)', 'IC', '600 N ALAMEDA ST', 34.05, -118.25)
    (200104715, '01-10-2020', '01-10-2020', 'Central', 510, 'VEHICLE - STOLEN', 0, '', 'STREET', 'IC', '14600 VANOWEN ST', 34.04, -118.24)
    (200104717, '01-10-2020', '01-09-2020', 'Central', 330, 'BURGLARY FROM VEHICLE', 46, 'F', 'PARKING LOT', 'IC', '100 JUDGE JOHN AISO ST', 34.04, -118.24)
    (200104718, '01-10-2020', '01-10-2020', 'Central', 624, 'BATTERY - SIMPLE ASSAULT', 55, 'F', 'STREET', 'IC', '19500 INGOMAR ST', 34.05, -118.25)
    (200104719, '01-10-2020', '01-08-2020', 'Central', 341, 'THEFT-GRAND ($950.01 & OVER)EXCPT,GUNS,FOWL,LIVESTK,PROD', 33, 'M', 'MUNICIPAL BUS LINE INCLUDES LADOT/DASH', 'IC', '700 S GRAND AV', 34.04, -118.26)
    (200104721, '01-10-2020', '01-10-2020', 'Central', 510, 'VEHICLE - STOLEN', 0, '', 'STREET', 'IC', '200 E 6TH ST', 34.04, -118.24)
    (200104726, '01-10-2020', '01-10-2020', 'Central', 310, 'BURGLARY', 27, 'M', 'MULTI-UNIT DWELLING (APARTMENT, DUPLEX, ETC)', 'AA', '800 S HILL ST', 34.05, -118.26)
    (200104727, '01-10-2020', '01-10-2020', 'Central', 624, 'BATTERY - SIMPLE ASSAULT', 48, 'M', 'SIDEWALK', 'IC', '200 W 7TH ST', 34.05, -118.25)
    (200104734, '01-11-2020', '01-10-2020', 'Central', 510, 'VEHICLE - STOLEN', 0, '', 'STREET', 'IC', '600 S OLIVE ST', 34.04, -118.23)
    (200104735, '01-11-2020', '01-10-2020', 'Central', 220, 'ATTEMPTED ROBBERY', 30, 'M', 'SIDEWALK', 'AA', '600 S SPRING ST', 34.05, -118.24)
    (200205570, '02-01-2020', '02-01-2020', 'Rampart', 510, 'VEHICLE - STOLEN', 0, '', 'STREET', 'IC', '7TH ST', 34.06, -118.27)
    (200104737, '01-11-2020', '01-11-2020', 'Central', 230, 'ASSAULT WITH DEADLY WEAPON, AGGRAVATED ASSAULT', 26, 'M', 'SIDEWALK', 'IC', '700 S GRAND AV', 34.05, -118.24)
    (200104738, '01-11-2020', '01-11-2020', 'Central', 230, 'ASSAULT WITH DEADLY WEAPON, AGGRAVATED ASSAULT', 26, 'M', 'SIDEWALK', 'IC', '700 W 7TH ST', 34.05, -118.24)
    (200104739, '01-11-2020', '01-10-2020', 'Central', 624, 'BATTERY - SIMPLE ASSAULT', 28, 'F', 'SIDEWALK', 'IC', '900 W OLYMPIC BL', 34.05, -118.26)
    (200104740, '01-11-2020', '01-10-2020', 'Central', 230, 'ASSAULT WITH DEADLY WEAPON, AGGRAVATED ASSAULT', 36, 'M', 'SINGLE FAMILY DWELLING', 'IC', '800 S FIGUEROA ST', 34.04, -118.27)
    (200104741, '01-11-2020', '01-10-2020', 'Central', 330, 'BURGLARY FROM VEHICLE', 0, 'M', 'PARKING LOT', 'IC', '200 BOYD ST', 34.04, -118.25)
    (200104742, '01-11-2020', '01-10-2020', 'Central', 740, 'VANDALISM - FELONY ($400 & OVER, ALL CHURCH VANDALISMS)', 33, 'F', 'VEHICLE, PASSENGER/TRUCK', 'IC', '5TH', 34.04, -118.26)
    (200104743, '01-11-2020', '01-09-2020', 'Central', 341, 'THEFT-GRAND ($950.01 & OVER)EXCPT,GUNS,FOWL,LIVESTK,PROD', 27, 'M', 'STREET', 'IC', '200 E 11TH ST', 34.05, -118.25)
    (200104744, '01-11-2020', '01-11-2020', 'Central', 320, 'BURGLARY, ATTEMPTED', 0, 'M', 'OTHER RESIDENCE', 'IC', '600 N BROADWAY', 34.06, -118.24)
    (200104745, '01-11-2020', '01-10-2020', 'Central', 740, 'VANDALISM - FELONY ($400 & OVER, ALL CHURCH VANDALISMS)', 0, 'M', 'HOSPITAL', 'AA', '1000 S HOPE ST', 34.04, -118.27)
    (200104749, '01-11-2020', '01-10-2020', 'Central', 440, 'THEFT PLAIN - PETTY ($950 & UNDER)', 48, 'M', 'MULTI-UNIT DWELLING (APARTMENT, DUPLEX, ETC)', 'IC', '1000 S FIGUEROA ST', 34.04, -118.24)
    (200104750, '01-11-2020', '01-11-2020', 'Central', 740, 'VANDALISM - FELONY ($400 & OVER, ALL CHURCH VANDALISMS)', 0, 'M', 'BUS STOP', 'IC', '600 W 7TH ST', 34.05, -118.25)
    (200104752, '01-11-2020', '01-11-2020', 'Central', 440, 'THEFT PLAIN - PETTY ($950 & UNDER)', 28, 'F', 'MULTI-UNIT DWELLING (APARTMENT, DUPLEX, ETC)', 'IC', '800 S OLIVE ST', 34.04, -118.24)
    (200104754, '01-11-2020', '01-11-2020', 'Central', 624, 'BATTERY - SIMPLE ASSAULT', 58, 'F', 'SIDEWALK', 'IC', 'FRIGATE', 34.05, -118.25)
    (200104755, '01-11-2020', '01-11-2020', 'Central', 624, 'BATTERY - SIMPLE ASSAULT', 51, 'M', 'SIDEWALK', 'IC', '1000 S ALVARADO ST', 34.04, -118.25)
    (200104759, '01-11-2020', '01-02-2020', 'Central', 354, 'THEFT OF IDENTITY', 64, 'F', 'MULTI-UNIT DWELLING (APARTMENT, DUPLEX, ETC)', 'IC', '6TH', 34.05, -118.24)
    (200104761, '01-11-2020', '01-10-2020', 'Central', 330, 'BURGLARY FROM VEHICLE', 32, 'M', 'PARKING LOT', 'IC', '1100 S FIGUEROA ST', 34.05, -118.25)
    (200104762, '01-11-2020', '01-11-2020', 'Central', 330, 'BURGLARY FROM VEHICLE', 32, 'M', 'PARKING UNDERGROUND/BUILDING', 'IC', '600 W 5TH ST', 34.04, -118.27)
    (200104763, '01-11-2020', '01-11-2020', 'Central', 510, 'VEHICLE - STOLEN', 0, '', 'STREET', 'IC', '300 S BROADWAY', 34.07, -118.23)
    (200104765, '01-11-2020', '01-11-2020', 'Central', 330, 'BURGLARY FROM VEHICLE', 39, 'M', 'ALLEY', 'IC', 'ORD', 34.03, -118.26)
    (200104766, '01-11-2020', '01-06-2020', 'Central', 740, 'VANDALISM - FELONY ($400 & OVER, ALL CHURCH VANDALISMS)', 38, 'M', 'VEHICLE, PASSENGER/TRUCK', 'IC', '200 N MAIN ST', 34.06, -118.25)
    (200104768, '01-11-2020', '01-10-2020', 'Central', 662, 'BUNCO, GRAND THEFT', 29, 'M', 'MULTI-UNIT DWELLING (APARTMENT, DUPLEX, ETC)', 'IC', 'SUNSET', 34.04, -118.26)
    (200104769, '01-11-2020', '01-11-2020', 'Central', 440, 'THEFT PLAIN - PETTY ($950 & UNDER)', 38, 'M', 'SIDEWALK', 'IC', '700 S MAIN ST', 34.06, -118.24)
    (200104770, '01-11-2020', '01-11-2020', 'Central', 350, 'THEFT, PERSON', 20, 'M', 'STREET', 'IC', '300 E 5TH ST', 34.05, -118.24)
    (200104772, '01-11-2020', '01-11-2020', 'Central', 624, 'BATTERY - SIMPLE ASSAULT', 57, 'M', 'MTA - RED LINE - 7TH AND METRO CENTER', 'IC', '2600 S CABRILLO AV', 34.05, -118.26)
    (200104774, '01-11-2020', '01-11-2020', 'Central', 624, 'BATTERY - SIMPLE ASSAULT', 65, 'F', 'MTA - PURPLE LINE - PERSHING SQUARE', 'IC', '100 S GRAND AV', 34.05, -118.25)
    (200104775, '01-11-2020', '01-11-2020', 'Central', 440, 'THEFT PLAIN - PETTY ($950 & UNDER)', 22, 'F', 'STREET', 'IC', '1200 S GRAND AV', 34.05, -118.25)
    (200104800, '01-11-2020', '01-11-2020', 'Central', 761, 'BRANDISH WEAPON', 22, 'M', 'PARKING LOT', 'IC', '600 S LOS ANGELES ST', 34.06, -118.23)
    (200104806, '01-12-2020', '01-10-2020', 'Central', 888, 'TRESPASSING', 0, 'M', 'LA UNION STATION (NOT LINE SPECIFIC)', 'IC', '800 W 255TH ST', 34.06, -118.24)
    (200104808, '01-12-2020', '01-11-2020', 'Central', 442, 'SHOPLIFTING - PETTY THEFT ($950 & UNDER)', 30, 'M', 'LA UNION STATION (NOT LINE SPECIFIC)', 'IC', '6300 6TH AV', 34.06, -118.24)
    (200104810, '01-09-2020', '01-09-2020', 'Central', 624, 'BATTERY - SIMPLE ASSAULT', 30, 'F', 'MTA - RED LINE - 7TH AND METRO CENTER', 'IC', '7800 BEEMAN AV', 34.05, -118.26)
    (200104813, '01-11-2020', '01-11-2020', 'Central', 624, 'BATTERY - SIMPLE ASSAULT', 65, 'M', 'SINGLE FAMILY DWELLING', 'IC', '300 N VERMONT AV', 34.07, -118.25)
    (200104814, '01-11-2020', '01-11-2020', 'Central', 624, 'BATTERY - SIMPLE ASSAULT', 28, 'M', 'OTHER STORE', 'IC', '3300 SAN MARINO ST', 34.05, -118.25)
    (200104815, '01-11-2020', '01-11-2020', 'Central', 624, 'BATTERY - SIMPLE ASSAULT', 41, 'F', 'MISSIONS/SHELTERS', 'IC', '15600 SIMONDS ST', 34.04, -118.24)
    (200104817, '01-11-2020', '01-11-2020', 'Central', 624, 'BATTERY - SIMPLE ASSAULT', 28, 'F', 'STAPLES CENTER *', 'IC', '800 S TREMAINE AV', 34.04, -118.27)
    (200104818, '01-12-2020', '01-12-2020', 'Central', 624, 'BATTERY - SIMPLE ASSAULT', 35, 'F', 'SIDEWALK', 'IC', '2400 COLORADO BL', 34.06, -118.24)
    (200104819, '01-11-2020', '01-11-2020', 'Central', 330, 'BURGLARY FROM VEHICLE', 35, 'M', 'SIDEWALK', 'IC', '3500 E 7TH ST', 34.05, -118.25)
    (200104820, '01-12-2020', '01-11-2020', 'Central', 330, 'BURGLARY FROM VEHICLE', 38, 'M', 'SIDEWALK', 'IC', '200 S WESTLAKE AV', 34.04, -118.24)
    (200104821, '01-11-2020', '01-11-2020', 'Central', 341, 'THEFT-GRAND ($950.01 & OVER)EXCPT,GUNS,FOWL,LIVESTK,PROD', 32, 'F', 'SIDEWALK', 'IC', '300 E 1ST ST', 34.04, -118.26)
    (200104822, '01-11-2020', '01-11-2020', 'Central', 480, 'BIKE - STOLEN', 39, 'F', 'SIDEWALK', 'IC', '400 HARTFORD AV', 34.05, -118.25)
    (200104823, '01-11-2020', '01-09-2020', 'Central', 350, 'THEFT, PERSON', 57, 'M', 'STAPLES CENTER *', 'IC', '1000 WILSHIRE BL', 34.04, -118.27)
    (200104826, '01-11-2020', '01-11-2020', 'Central', 341, 'THEFT-GRAND ($950.01 & OVER)EXCPT,GUNS,FOWL,LIVESTK,PROD', 56, 'M', 'OTHER BUSINESS', 'IC', '1600 W 204TH ST', 34.04, -118.26)
    (200104829, '01-12-2020', '01-12-2020', 'Central', 740, 'VANDALISM - FELONY ($400 & OVER, ALL CHURCH VANDALISMS)', 29, 'M', 'VEHICLE, PASSENGER/TRUCK', 'IC', '7900 BOTHWELL RD', 34.05, -118.24)
    (200918367, '12-12-2020', '12-12-2020', 'Van Nuys', 230, 'ASSAULT WITH DEADLY WEAPON, AGGRAVATED ASSAULT', 45, 'M', 'SIDEWALK', 'IC', '1500 VINE ST', 34.2, -118.46)
    (200104835, '01-11-2020', '01-11-2020', 'Central', 901, 'VIOLATION OF RESTRAINING ORDER', 47, 'F', 'MULTI-UNIT DWELLING (APARTMENT, DUPLEX, ETC)', 'IC', '100 AVENUE 56', 34.06, -118.24)
    (200104836, '01-12-2020', '01-11-2020', 'Central', 740, 'VANDALISM - FELONY ($400 & OVER, ALL CHURCH VANDALISMS)', 30, 'M', 'VEHICLE, PASSENGER/TRUCK', 'IC', '1100 S FIGUEROA ST', 34.05, -118.24)
    (201007153, '03-12-2020', '03-12-2020', 'West Valley', 888, 'TRESPASSING', 45, 'F', 'SINGLE FAMILY DWELLING', 'AA', '900 S GRAND AV', 34.21, -118.56)
    (200104842, '01-12-2020', '01-08-2020', 'Central', 330, 'BURGLARY FROM VEHICLE', 34, 'F', 'PARKING LOT', 'IC', '6600 BRYNHURST AV', 34.05, -118.26)
    (200104843, '01-12-2020', '01-11-2020', 'Central', 330, 'BURGLARY FROM VEHICLE', 57, 'F', 'PARKING LOT', 'IC', '1600 W 54TH ST', 34.04, -118.25)
    (200104844, '01-12-2020', '01-12-2020', 'Central', 230, 'ASSAULT WITH DEADLY WEAPON, AGGRAVATED ASSAULT', 45, 'M', 'STREET', 'IC', '6200 MT ANGELUS DR', 34.04, -118.24)
    (200104847, '01-12-2020', '01-11-2020', 'Central', 740, 'VANDALISM - FELONY ($400 & OVER, ALL CHURCH VANDALISMS)', 28, 'F', 'VEHICLE, PASSENGER/TRUCK', 'IC', '1600 W 54TH ST', 34.05, -118.26)
    (200104848, '01-12-2020', '01-11-2020', 'Central', 930, 'CRIMINAL THREATS - NO WEAPON DISPLAYED', 62, 'M', 'STREET', 'IC', '200 WOODRUFF AV', 34.05, -118.25)
    (200104849, '01-12-2020', '01-12-2020', 'Central', 442, 'SHOPLIFTING - PETTY THEFT ($950 & UNDER)', 21, 'F', 'DRUG STORE', 'IC', '2200 MARICOPA DR', 34.05, -118.26)
    (200104850, '01-12-2020', '01-12-2020', 'Central', 310, 'BURGLARY', 27, 'M', 'DEPARTMENT STORE', 'IC', '3900 URSULA AV', 34.05, -118.25)
    (200104851, '01-12-2020', '01-11-2020', 'Central', 350, 'THEFT, PERSON', 26, 'F', 'NIGHT CLUB (OPEN EVENINGS ONLY)', 'IC', '5TH', 34.05, -118.25)
    (200104853, '01-12-2020', '01-11-2020', 'Central', 440, 'THEFT PLAIN - PETTY ($950 & UNDER)', 26, 'F', 'RESTAURANT/FAST FOOD', 'IC', '300 E 5TH ST', 34.05, -118.26)
    (200104857, '01-12-2020', '01-05-2020', 'Central', 420, 'THEFT FROM MOTOR VEHICLE - PETTY ($950 & UNDER)', 0, '', 'PARKING LOT', 'IC', '1400 W HILL DR', 34.04, -118.27)
    (200104860, '01-12-2020', '01-10-2020', 'Central', 341, 'THEFT-GRAND ($950.01 & OVER)EXCPT,GUNS,FOWL,LIVESTK,PROD', 29, 'M', 'PARKING LOT', 'IC', '00 OLVERA ST', 34.05, -118.26)
    (200104861, '01-12-2020', '01-12-2020', 'Central', 210, 'ROBBERY', 23, 'M', 'DEPARTMENT STORE', 'AO', '400 W 8TH ST', 34.05, -118.26)
    (200104863, '01-12-2020', '01-11-2020', 'Central', 330, 'BURGLARY FROM VEHICLE', 38, 'F', 'PARKING LOT', 'IC', '600 W SUNSET BL', 34.05, -118.27)
    (200104865, '01-12-2020', '01-12-2020', 'Central', 330, 'BURGLARY FROM VEHICLE', 27, 'M', 'PARKING LOT', 'IC', '700 W 7TH ST', 34.05, -118.26)
    (200104868, '01-12-2020', '01-08-2020', 'Central', 624, 'BATTERY - SIMPLE ASSAULT', 35, 'M', 'MULTI-UNIT DWELLING (APARTMENT, DUPLEX, ETC)', 'IC', 'BOYD ST', 34.05, -118.25)
    (200104869, '01-12-2020', '01-12-2020', 'Central', 624, 'BATTERY - SIMPLE ASSAULT', 60, 'M', 'MTA BUS', 'IC', '500 WALL ST', 34.05, -118.25)
    (200104872, '01-12-2020', '01-12-2020', 'Central', 330, 'BURGLARY FROM VEHICLE', 26, 'M', 'STREET', 'IC', '800 FRANCISCO ST', 34.04, -118.26)
    (200104873, '01-12-2020', '01-12-2020', 'Central', 330, 'BURGLARY FROM VEHICLE', 36, 'M', 'MULTI-UNIT DWELLING (APARTMENT, DUPLEX, ETC)', 'IC', '600 N SPRING ST', 34.06, -118.24)
    (200104874, '01-12-2020', '01-11-2020', 'Central', 740, 'VANDALISM - FELONY ($400 & OVER, ALL CHURCH VANDALISMS)', 45, 'M', 'VEHICLE, PASSENGER/TRUCK', 'IC', 'ALPINE', 34.04, -118.26)
    (200104875, '01-12-2020', '01-12-2020', 'Central', 888, 'TRESPASSING', 0, 'X', 'BAR/SPORTS BAR (OPEN DAY & NIGHT)', 'IC', 'LOS ANGELES', 34.05, -118.27)
    (200104879, '01-12-2020', '01-12-2020', 'Central', 210, 'ROBBERY', 0, 'X', 'OTHER STORE', 'IC', '800 N ALAMEDA ST', 34.05, -118.26)
    (200104880, '01-12-2020', '01-12-2020', 'Central', 440, 'THEFT PLAIN - PETTY ($950 & UNDER)', 20, 'F', 'SIDEWALK', 'IC', '800 W OLYMPIC BL', 34.05, -118.26)
    (200508173, '04-12-2020', '04-12-2020', 'Harbor', 890, 'FAILURE TO YIELD', 0, 'X', 'STREET', 'AA', '800 W OLYMPIC BL', 33.78, -118.28)
    (200204368, '01-08-2020', '01-08-2020', 'Rampart', 888, 'TRESPASSING', 19, 'X', 'LIBRARY', 'IC', '800 W OLYMPIC BL', 34.05, -118.28)
    (200106568, '02-06-2020', '02-05-2020', 'Central', 351, 'PURSE SNATCHING', 54, 'F', 'STREET', 'IC', '600 S OLIVE ST', 34.04, -118.25)
    (200104884, '01-12-2020', '01-11-2020', 'Central', 341, 'THEFT-GRAND ($950.01 & OVER)EXCPT,GUNS,FOWL,LIVESTK,PROD', 44, 'M', 'STAPLES CENTER *', 'IC', '800 S FIGUEROA ST', 34.04, -118.27)
    (200104885, '01-12-2020', '01-12-2020', 'Central', 480, 'BIKE - STOLEN', 26, 'M', 'LIBRARY', 'IC', '400 W 8TH ST', 34.05, -118.25)
    (200104886, '01-12-2020', '01-12-2020', 'Central', 440, 'THEFT PLAIN - PETTY ($950 & UNDER)', 22, 'F', 'MARKET', 'IC', '800 S GRAND AV', 34.05, -118.25)
    (200104887, '01-12-2020', '01-12-2020', 'Central', 946, 'OTHER MISCELLANEOUS CRIME', 32, 'M', 'STREET', 'AO', '7TH ST', 34.06, -118.24)
    (200104896, '01-08-2020', '01-03-2020', 'Central', 956, 'LETTERS, LEWD  -  TELEPHONE CALLS, LEWD', 0, 'X', 'GOVERNMENT FACILITY (FEDERAL,STATE, COUNTY & CITY)', 'IC', '700 S SPRING ST', 34.05, -118.24)
    (200610092, '05-10-2020', '05-10-2020', 'Hollywood', 330, 'BURGLARY FROM VEHICLE', 22, 'F', 'STREET', 'AO', '1200 S OLIVE ST', 34.1, -118.33)
    (200104955, '01-12-2020', '01-12-2020', 'Central', 624, 'BATTERY - SIMPLE ASSAULT', 21, 'M', 'MULTI-UNIT DWELLING (APARTMENT, DUPLEX, ETC)', 'IC', '400 WITMER ST', 34.04, -118.25)
    (200104997, '01-10-2020', '01-06-2020', 'Central', 624, 'BATTERY - SIMPLE ASSAULT', 32, 'F', 'STREET', 'IC', '700 W 7TH ST', 34.04, -118.25)
    (200510203, '06-04-2020', '06-04-2020', 'Harbor', 510, 'VEHICLE - STOLEN', 0, '', 'STREET', 'IC', '600 S SPRING ST', 33.72, -118.29)
    (200105023, '01-12-2020', '01-11-2020', 'Central', 330, 'BURGLARY FROM VEHICLE', 28, 'M', 'UNDERPASS/BRIDGE*', 'IC', '1200 S MAIN ST', 34.05, -118.23)
    (200105026, '01-06-2020', '01-05-2020', 'Central', 341, 'THEFT-GRAND ($950.01 & OVER)EXCPT,GUNS,FOWL,LIVESTK,PROD', 22, 'M', 'SIDEWALK', 'IC', '700 YALE ST', 34.06, -118.25)
    (200105030, '01-08-2020', '01-07-2020', 'Central', 330, 'BURGLARY FROM VEHICLE', 31, 'M', 'TRANSPORTATION FACILITY (AIRPORT)', 'IC', '1600 S HOPE ST', 34.04, -118.26)
    (201115511, '11-07-2020', '11-07-2020', 'Northeast', 740, 'VANDALISM - FELONY ($400 & OVER, ALL CHURCH VANDALISMS)', 0, 'M', 'VEHICLE, PASSENGER/TRUCK', 'AA', 'HILL', 34.08, -118.26)
    (200105074, '01-11-2020', '01-10-2020', 'Central', 330, 'BURGLARY FROM VEHICLE', 30, 'M', 'STREET', 'IC', 'BROADWAY', 34.04, -118.25)
    (200105090, '01-11-2020', '01-10-2020', 'Central', 330, 'BURGLARY FROM VEHICLE', 22, 'F', 'SIDEWALK', 'IC', '500 S SAN PEDRO ST', 34.04, -118.25)
    (200500577, '03-10-2020', '03-10-2020', 'Harbor', 888, 'TRESPASSING', 53, 'M', 'SINGLE FAMILY DWELLING', 'IC', '2ND', 33.79, -118.29)
    (201200943, '10-11-2020', '10-11-2020', '77th Street', 820, 'ORAL COPULATION', 8, 'F', 'SINGLE FAMILY DWELLING', 'AO', '800 N ALAMEDA ST', 33.98, -118.32)
    (211507896, '04-11-2021', '11-07-2020', 'N Hollywood', 354, 'THEFT OF IDENTITY', 31, 'M', 'SINGLE FAMILY DWELLING', 'IC', '100 W WASHINGTON BL', 34.21, -118.41)
    (200616504, '10-10-2020', '10-09-2020', 'Hollywood', 210, 'ROBBERY', 29, 'F', 'GARAGE/CARPORT', 'IC', '900 S FIGUEROA ST', 34.1, -118.32)
    (200204372, '01-09-2020', '01-08-2020', 'Rampart', 510, 'VEHICLE - STOLEN', 0, '', 'STREET', 'IC', '500 S FLOWER ST', 34.08, -118.3)
    (222013040, '08-06-2022', '06-04-2020', 'Olympic', 354, 'THEFT OF IDENTITY', 60, 'M', 'SINGLE FAMILY DWELLING', 'IC', '2200 W SUNSET BL', 34.05, -118.3)
    (211715638, '12-01-2021', '12-09-2020', 'Devonshire', 354, 'THEFT OF IDENTITY', 56, 'F', 'SINGLE FAMILY DWELLING', 'IC', 'BURLINGTON', 34.28, -118.47)
    (200516317, '11-07-2020', '11-07-2020', 'Harbor', 886, 'DISTURBING THE PEACE', 38, 'M', 'SINGLE FAMILY DWELLING', 'AO', '1700 W 6TH ST', 33.71, -118.29)
    (220705246, '02-03-2022', '02-11-2020', 'Wilshire', 341, 'THEFT-GRAND ($950.01 & OVER)EXCPT,GUNS,FOWL,LIVESTK,PROD', 57, 'F', 'SINGLE FAMILY DWELLING', 'IC', '7900 WOODMAN AV', 34.06, -118.34)
    (201104052, '01-01-2020', '01-01-2020', 'Northeast', 740, 'VANDALISM - FELONY ($400 & OVER, ALL CHURCH VANDALISMS)', 0, 'X', 'MULTI-UNIT DWELLING (APARTMENT, DUPLEX, ETC)', 'AA', '2100 JAMES M WOOD BL', 34.14, -118.22)
    (200408506, '05-04-2020', '05-04-2020', 'Hollenbeck', 510, 'VEHICLE - STOLEN', 0, '', 'STREET', 'IC', 'NORMAL AV', 34.02, -118.2)
    (200204446, '01-09-2020', '01-08-2020', 'Rampart', 420, 'THEFT FROM MOTOR VEHICLE - PETTY ($950 & UNDER)', 0, '', 'STREET', 'IC', '400 LOMA DR', 34.06, -118.27)
    (200106255, '02-02-2020', '02-02-2020', 'Central', 648, 'ARSON', 54, 'F', 'OTHER BUSINESS', 'IC', 'JAMES M WOOD', 34.05, -118.24)
    (210206385, '03-01-2021', '09-01-2020', 'Rampart', 812, 'CRM AGNST CHLD (13 OR UNDER) (14-15 & SUSP 10 YRS OLDER)', 9, 'F', 'MULTI-UNIT DWELLING (APARTMENT, DUPLEX, ETC)', 'AO', '1400 COURTLAND AV', 34.06, -118.26)
    (200218310, '12-07-2020', '12-05-2020', 'Rampart', 510, 'VEHICLE - STOLEN', 0, '', 'PARKING LOT', 'AO', '8TH ST', 34.05, -118.26)
    (200504370, '01-09-2020', '01-08-2020', 'Harbor', 510, 'VEHICLE - STOLEN', 0, '', 'STREET', 'IC', '500 BRITTANIA ST', 33.85, -118.31)
    (201011914, '08-10-2020', '08-02-2020', 'West Valley', 330, 'BURGLARY FROM VEHICLE', 0, 'M', 'STREET', 'IC', 'CONNECTICUT', 34.21, -118.56)
    (200404158, '01-05-2020', '01-04-2020', 'Hollenbeck', 510, 'VEHICLE - STOLEN', 0, '', 'STREET', 'IC', '7TH ST', 34.07, -118.22)
    (200613614, '08-06-2020', '08-06-2020', 'Hollywood', 624, 'BATTERY - SIMPLE ASSAULT', 19, 'F', 'SINGLE FAMILY DWELLING', 'IC', 'ADDISON', 34.1, -118.33)
    (200508100, '04-09-2020', '04-08-2020', 'Harbor', 330, 'BURGLARY FROM VEHICLE', 48, 'M', 'STREET', 'IC', 'PICO', 33.78, -118.31)
    (201110303, '06-11-2020', '06-08-2020', 'Northeast', 310, 'BURGLARY', 0, 'M', 'OTHER BUSINESS', 'IC', '600 S UNION AV', 34.11, -118.19)
    (200105788, '01-05-2020', '01-05-2020', 'Central', 341, 'THEFT-GRAND ($950.01 & OVER)EXCPT,GUNS,FOWL,LIVESTK,PROD', 37, 'M', 'STAPLES CENTER *', 'IC', '2300 KENT ST', 34.04, -118.27)
    (200504494, '01-11-2020', '01-11-2020', 'Harbor', 930, 'CRIMINAL THREATS - NO WEAPON DISPLAYED', 33, 'F', 'OTHER BUSINESS', 'AA', '3800 DUBLIN AV', 33.74, -118.29)
    (201214500, '06-11-2020', '06-11-2020', '77th Street', 624, 'BATTERY - SIMPLE ASSAULT', 30, 'F', 'MULTI-UNIT DWELLING (APARTMENT, DUPLEX, ETC)', 'JO', 'SANTO TOMAS DR', 33.98, -118.33)
    (201226353, '12-05-2020', '12-05-2020', '77th Street', 230, 'ASSAULT WITH DEADLY WEAPON, AGGRAVATED ASSAULT', 48, 'F', 'STREET', 'AO', '700 EXPOSITION BL', 33.99, -118.31)
    (201110326, '06-12-2020', '06-11-2020', 'Northeast', 510, 'VEHICLE - STOLEN', 0, '', 'STREET', 'IC', '3900 S WESTERN AV', 34.11, -118.19)
    (201108104, '04-07-2020', '04-06-2020', 'Northeast', 510, 'VEHICLE - STOLEN', 0, '', 'STREET', 'IC', '3500 ENVILLE PL', 34.09, -118.28)
    (201226354, '12-05-2020', '12-05-2020', '77th Street', 230, 'ASSAULT WITH DEADLY WEAPON, AGGRAVATED ASSAULT', 29, 'M', 'STREET', 'AO', '48TH ST', 33.99, -118.31)
    (200815069, '10-09-2020', '10-09-2020', 'West LA', 320, 'BURGLARY, ATTEMPTED', 68, 'F', 'SINGLE FAMILY DWELLING', 'IC', '1500 EXPOSITION BL', 34.08, -118.44)
    (201108147, '04-08-2020', '04-08-2020', 'Northeast', 745, 'VANDALISM - MISDEAMEANOR ($399 OR UNDER)', 63, 'F', 'SINGLE FAMILY DWELLING', 'AO', '1100 W 20TH ST', 34.11, -118.22)
    (200304583, '01-10-2020', '01-10-2020', 'Southwest', 901, 'VIOLATION OF RESTRAINING ORDER', 37, 'F', 'MULTI-UNIT DWELLING (APARTMENT, DUPLEX, ETC)', 'AO', '3400 S LA BREA AV', 34.02, -118.35)
    (200106179, '02-01-2020', '02-01-2020', 'Central', 220, 'ATTEMPTED ROBBERY', 59, 'M', 'SIDEWALK', 'IC', '900 W 41ST DR', 34.05, -118.25)
    (200106182, '02-01-2020', '02-01-2020', 'Central', 440, 'THEFT PLAIN - PETTY ($950 & UNDER)', 45, 'M', 'MISSIONS/SHELTERS', 'IC', '1500 W 37TH ST', 34.05, -118.24)
    (201109103, '05-07-2020', '05-07-2020', 'Northeast', 888, 'TRESPASSING', 60, 'M', 'SINGLE FAMILY DWELLING', 'IC', '700 W 27TH ST', 34.14, -118.2)
    (200106197, '02-01-2020', '02-01-2020', 'Central', 745, 'VANDALISM - MISDEAMEANOR ($399 OR UNDER)', 0, 'X', 'RESTAURANT/FAST FOOD', 'IC', '4000 S WESTERN AV', 34.04, -118.25)
    (200106198, '02-01-2020', '02-01-2020', 'Central', 624, 'BATTERY - SIMPLE ASSAULT', 52, 'F', 'OTHER BUSINESS', 'IC', '3200 W VERNON AV', 34.06, -118.24)
    (200507056, '03-11-2020', '03-11-2020', 'Harbor', 740, 'VANDALISM - FELONY ($400 & OVER, ALL CHURCH VANDALISMS)', 39, 'M', 'VEHICLE, PASSENGER/TRUCK', 'AO', '1400 W 37TH PL', 33.74, -118.29)
    (200106208, '02-01-2020', '02-01-2020', 'Central', 420, 'THEFT FROM MOTOR VEHICLE - PETTY ($950 & UNDER)', 0, '', 'STREET', 'IC', '1900 W 35TH PL', 34.06, -118.24)
    (200106209, '02-01-2020', '02-01-2020', 'Central', 442, 'SHOPLIFTING - PETTY THEFT ($950 & UNDER)', 35, 'M', 'DEPARTMENT STORE', 'IC', '9300 VAN NUYS BL', 34.05, -118.26)
    (200106210, '02-01-2020', '02-01-2020', 'Central', 230, 'ASSAULT WITH DEADLY WEAPON, AGGRAVATED ASSAULT', 40, 'M', 'ALLEY', 'IC', 'W 28TH ST', 34.05, -118.25)
    (200106217, '02-01-2020', '02-01-2020', 'Central', 625, 'OTHER ASSAULT', 62, 'M', 'MULTI-UNIT DWELLING (APARTMENT, DUPLEX, ETC)', 'IC', '3700 SANTA ROSALIA DR', 34.04, -118.25)
    (200106560, '02-05-2020', '02-05-2020', 'Central', 888, 'TRESPASSING', 0, 'X', 'BAR/COCKTAIL/NIGHTCLUB', 'IC', '4000 STEVELY AV', 34.05, -118.26)
    (200106220, '02-01-2020', '02-01-2020', 'Central', 230, 'ASSAULT WITH DEADLY WEAPON, AGGRAVATED ASSAULT', 29, 'M', 'STREET', 'IC', '3600 CRENSHAW BL', 34.06, -118.24)
    (200106221, '02-01-2020', '02-01-2020', 'Central', 440, 'THEFT PLAIN - PETTY ($950 & UNDER)', 44, 'M', 'SIDEWALK', 'IC', '1200 W 30TH ST', 34.06, -118.24)
    (200106222, '02-02-2020', '02-01-2020', 'Central', 330, 'BURGLARY FROM VEHICLE', 36, 'F', 'PARKING LOT', 'IC', '4000 CRENSHAW BL', 34.04, -118.26)
    (200106224, '02-02-2020', '02-01-2020', 'Central', 230, 'ASSAULT WITH DEADLY WEAPON, AGGRAVATED ASSAULT', 26, 'M', 'LA UNION STATION (NOT LINE SPECIFIC)', 'AA', '4100 S FIGUEROA ST', 34.06, -118.24)
    (200106225, '02-02-2020', '02-01-2020', 'Central', 624, 'BATTERY - SIMPLE ASSAULT', 45, 'M', 'NIGHT CLUB (OPEN EVENINGS ONLY)', 'IC', '4900 W ADAMS BL', 34.05, -118.26)
    (200106226, '02-02-2020', '02-01-2020', 'Central', 624, 'BATTERY - SIMPLE ASSAULT', 36, 'F', 'NIGHT CLUB (OPEN EVENINGS ONLY)', 'IC', '700 W WASHINGTON BL', 34.05, -118.26)
    (200106227, '02-02-2020', '02-01-2020', 'Central', 624, 'BATTERY - SIMPLE ASSAULT', 19, 'F', 'NIGHT CLUB (OPEN EVENINGS ONLY)', 'IC', '2700 S SYCAMORE AV', 34.05, -118.26)
    (200106228, '02-02-2020', '02-01-2020', 'Central', 624, 'BATTERY - SIMPLE ASSAULT', 17, 'F', 'NIGHT CLUB (OPEN EVENINGS ONLY)', 'IC', '2100 OAK ST', 34.05, -118.26)
    (200106229, '02-01-2020', '02-01-2020', 'Central', 330, 'BURGLARY FROM VEHICLE', 24, 'M', 'PARKING LOT', 'IC', '800 W ADAMS BL', 34.05, -118.25)
    (200106230, '02-02-2020', '02-01-2020', 'Central', 341, 'THEFT-GRAND ($950.01 & OVER)EXCPT,GUNS,FOWL,LIVESTK,PROD', 23, 'F', 'RESTAURANT/FAST FOOD', 'IC', '10900 WELLWORTH AV', 34.05, -118.26)
    (200106231, '02-02-2020', '02-01-2020', 'Central', 341, 'THEFT-GRAND ($950.01 & OVER)EXCPT,GUNS,FOWL,LIVESTK,PROD', 31, 'M', 'HOTEL', 'IC', '3500 S FLOWER ST', 34.04, -118.26)
    (200106232, '02-02-2020', '01-12-2020', 'Central', 354, 'THEFT OF IDENTITY', 27, 'M', 'OTHER PREMISE', 'IC', '2400 S VERMONT AV', 34.05, -118.26)
    (200106236, '02-02-2020', '02-02-2020', 'Central', 230, 'ASSAULT WITH DEADLY WEAPON, AGGRAVATED ASSAULT', 30, 'M', 'MUNICIPAL BUS LINE INCLUDES LADOT/DASH', 'IC', '1100 W 39TH PL', 34.05, -118.26)
    (200106237, '02-02-2020', '02-01-2020', 'Central', 330, 'BURGLARY FROM VEHICLE', 25, 'F', 'STREET', 'IC', '2300 W 48TH ST', 34.04, -118.27)
    (200106238, '02-02-2020', '02-01-2020', 'Central', 330, 'BURGLARY FROM VEHICLE', 25, 'F', 'PARKING LOT', 'IC', '4600 MARTIN LUTHER KING BL', 34.04, -118.25)
    (200106239, '02-02-2020', '02-02-2020', 'Central', 350, 'THEFT, PERSON', 22, 'F', 'NIGHT CLUB (OPEN EVENINGS ONLY)', 'IC', '2000 W MARTIN LUTHER KING JR BL', 34.04, -118.26)
    (200106242, '02-02-2020', '02-02-2020', 'Central', 624, 'BATTERY - SIMPLE ASSAULT', 23, 'M', 'STREET', 'IC', '17800 MARGATE ST', 34.05, -118.23)
    (200106245, '02-02-2020', '02-01-2020', 'Central', 440, 'THEFT PLAIN - PETTY ($950 & UNDER)', 0, 'M', 'STREET', 'IC', '5000 OBAMA BL', 34.05, -118.25)
    (200106246, '02-02-2020', '02-01-2020', 'Central', 440, 'THEFT PLAIN - PETTY ($950 & UNDER)', 27, 'M', 'MULTI-UNIT DWELLING (APARTMENT, DUPLEX, ETC)', 'IC', 'ADAMS BL', 34.04, -118.26)
    (200106253, '02-02-2020', '02-01-2020', 'Central', 510, 'VEHICLE - STOLEN', 0, 'F', 'STREET', 'IC', '3900 S BUDLONG AV', 34.04, -118.26)
    (200106257, '02-02-2020', '02-02-2020', 'Central', 442, 'SHOPLIFTING - PETTY THEFT ($950 & UNDER)', 35, 'M', 'OTHER STORE', 'IC', '02900 S LA BREA AV', 34.05, -118.26)
    (200106266, '02-02-2020', '02-02-2020', 'Central', 623, 'BATTERY POLICE (SIMPLE)', 40, 'M', 'SIDEWALK', 'AA', '2500 S FIGUEROA ST', 34.05, -118.25)
    (200106270, '02-02-2020', '02-02-2020', 'Central', 440, 'THEFT PLAIN - PETTY ($950 & UNDER)', 38, 'M', 'RESTAURANT/FAST FOOD', 'IC', '3600 WATT WY', 34.06, -118.23)
    (200812870, '08-11-2020', '08-02-2020', 'West LA', 745, 'VANDALISM - MISDEAMEANOR ($399 OR UNDER)', 22, 'F', 'SINGLE FAMILY DWELLING', 'IC', '3600 S SAINT ANDREWS PL', 34.05, -118.44)
    (201113281, '09-04-2020', '09-02-2020', 'Northeast', 310, 'BURGLARY', 37, 'F', 'GARAGE/CARPORT', 'IC', '3600 S SAINT ANDREWS PL', 34.09, -118.28)
    (200106283, '02-02-2020', '02-01-2020', 'Central', 330, 'BURGLARY FROM VEHICLE', 28, 'M', 'PARKING LOT', 'IC', '4300 BRIGHTON AV', 34.04, -118.26)
    (200106285, '02-02-2020', '02-02-2020', 'Central', 888, 'TRESPASSING', 0, 'F', 'MUSEUM', 'IC', '2400 W 48TH ST', 34.05, -118.25)
    (200106288, '02-02-2020', '02-01-2020', 'Central', 420, 'THEFT FROM MOTOR VEHICLE - PETTY ($950 & UNDER)', 0, 'F', 'PARKING LOT', 'IC', '2700 S FIGUEROA ST', 34.05, -118.23)
    (200106289, '02-02-2020', '02-01-2020', 'Central', 230, 'ASSAULT WITH DEADLY WEAPON, AGGRAVATED ASSAULT', 73, 'M', 'SIDEWALK', 'AA', '4800 7TH AV', 34.04, -118.26)
    (200106290, '02-02-2020', '02-02-2020', 'Central', 920, 'KIDNAPPING - GRAND ATTEMPT', 12, 'M', 'SIDEWALK', 'IC', '4100 PALMWOOD DR', 34.05, -118.24)
    (201226350, '12-05-2020', '12-05-2020', '77th Street', 230, 'ASSAULT WITH DEADLY WEAPON, AGGRAVATED ASSAULT', 30, 'M', 'STREET', 'AO', '600 W 42ND PL', 33.99, -118.31)
    (200106293, '02-02-2020', '02-02-2020', 'Central', 330, 'BURGLARY FROM VEHICLE', 24, 'M', 'STREET', 'IC', 'OBAMA BL', 34.04, -118.27)
    (200218546, '12-12-2020', '12-11-2020', 'Rampart', 745, 'VANDALISM - MISDEAMEANOR ($399 OR UNDER)', 42, 'M', 'VEHICLE, PASSENGER/TRUCK', 'AO', 'SANTA MONICA FY', 34.06, -118.26)
    (200106300, '02-02-2020', '02-02-2020', 'Central', 440, 'THEFT PLAIN - PETTY ($950 & UNDER)', 59, 'F', 'STREET', 'IC', '3500 S LA CIENEGA BL', 34.05, -118.25)
    (200106301, '02-02-2020', '02-02-2020', 'Central', 310, 'BURGLARY', 32, 'M', 'MULTI-UNIT DWELLING (APARTMENT, DUPLEX, ETC)', 'IC', '7TH AV', 34.06, -118.25)
    (200106305, '02-03-2020', '02-03-2020', 'Central', 350, 'THEFT, PERSON', 37, 'M', 'SIDEWALK', 'IC', '2700 RAYMOND AV', 34.04, -118.25)
    (200106308, '02-03-2020', '02-02-2020', 'Central', 624, 'BATTERY - SIMPLE ASSAULT', 33, 'M', 'MTA - RED LINE - CIVIC CENTER/GRAND PARK', 'IC', '2100 W 29TH PL', 34.05, -118.25)
    (200106309, '02-03-2020', '02-02-2020', 'Central', 745, 'VANDALISM - MISDEAMEANOR ($399 OR UNDER)', 25, 'M', 'VEHICLE, PASSENGER/TRUCK', 'IC', '3500 S LA CIENEGA BL', 34.05, -118.25)
    (200106375, '02-03-2020', '01-03-2020', 'Central', 624, 'BATTERY - SIMPLE ASSAULT', 53, 'F', 'OTHER BUSINESS', 'IC', '3400 EXPOSITION BL', 34.05, -118.26)
    (200106443, '02-05-2020', '02-04-2020', 'Central', 745, 'VANDALISM - MISDEAMEANOR ($399 OR UNDER)', 50, 'M', 'LIBRARY', 'IC', '4100 PALMWOOD DR', 34.05, -118.25)
    (200106445, '02-05-2020', '02-04-2020', 'Central', 210, 'ROBBERY', 61, 'F', 'SIDEWALK', 'IC', '1100 W 39TH ST', 34.04, -118.25)
    (200106312, '02-03-2020', '02-03-2020', 'Central', 624, 'BATTERY - SIMPLE ASSAULT', 26, 'M', 'STREET', 'IC', '2500 CLYDE AV', 34.05, -118.26)
    (200106318, '02-03-2020', '01-07-2020', 'Central', 330, 'BURGLARY FROM VEHICLE', 29, 'M', 'STREET', 'IC', '5400 GEER AV', 34.04, -118.26)
    (200106319, '02-01-2020', '02-01-2020', 'Central', 480, 'BIKE - STOLEN', 44, 'M', 'OTHER/OUTSIDE', 'IC', '5500 CARLIN ST', 34.04, -118.26)
    (200106320, '02-02-2020', '02-02-2020', 'Central', 440, 'THEFT PLAIN - PETTY ($950 & UNDER)', 18, 'M', 'RESTAURANT/FAST FOOD', 'IC', '900 W JEFFERSON BL', 34.05, -118.26)
    (200106321, '02-03-2020', '02-02-2020', 'Central', 745, 'VANDALISM - MISDEAMEANOR ($399 OR UNDER)', 0, 'M', 'HORSE RACING/SANTA ANITA PARK*', 'IC', '1100 W 28TH ST', 34.05, -118.24)
    (200106327, '02-03-2020', '02-02-2020', 'Central', 330, 'BURGLARY FROM VEHICLE', 24, 'M', 'PARKING UNDERGROUND/BUILDING', 'IC', '24100 GILMORE ST', 34.04, -118.26)
    (201813529, '07-05-2020', '07-05-2020', 'Southeast', 624, 'BATTERY - SIMPLE ASSAULT', 22, 'F', 'DRIVEWAY', 'AA', '5000 OBAMA BL', 33.96, -118.26)
    (200106330, '02-03-2020', '02-03-2020', 'Central', 624, 'BATTERY - SIMPLE ASSAULT', 27, 'F', 'MTA BUS', 'IC', '1200 W 37TH PL', 34.05, -118.25)
    (200106331, '02-03-2020', '02-03-2020', 'Central', 330, 'BURGLARY FROM VEHICLE', 29, 'F', 'STREET', 'IC', '4200 S HARVARD BL', 34.05, -118.23)
    (200106333, '02-03-2020', '02-03-2020', 'Central', 480, 'BIKE - STOLEN', 42, 'M', 'GOVERNMENT FACILITY (FEDERAL,STATE, COUNTY & CITY)', 'IC', '1600 W 38TH ST', 34.05, -118.24)
    (200106340, '02-03-2020', '02-01-2020', 'Central', 442, 'SHOPLIFTING - PETTY THEFT ($950 & UNDER)', 35, 'M', 'OTHER STORE', 'IC', '2800 W 42ND ST', 34.05, -118.26)
    (200106343, '02-03-2020', '02-01-2020', 'Central', 648, 'ARSON', 56, 'F', 'DRIVEWAY', 'IC', '3700 SANTA ROSALIA DR', 34.04, -118.25)
    (200106345, '02-03-2020', '02-03-2020', 'Central', 230, 'ASSAULT WITH DEADLY WEAPON, AGGRAVATED ASSAULT', 42, 'M', 'STREET', 'AA', 'BRONSON AV', 34.06, -118.24)
    (200106346, '02-03-2020', '02-03-2020', 'Central', 850, 'INDECENT EXPOSURE', 72, 'F', 'LIBRARY', 'IC', '5300 BLACKWELDER ST', 34.05, -118.25)
    (200106347, '02-03-2020', '02-03-2020', 'Central', 850, 'INDECENT EXPOSURE', 25, 'F', 'LIBRARY', 'IC', '2600 RAYMOND AV', 34.05, -118.25)
    (200106350, '02-03-2020', '02-03-2020', 'Central', 624, 'BATTERY - SIMPLE ASSAULT', 73, 'F', 'SIDEWALK', 'IC', 'VERNON AV', 34.04, -118.25)
    (200106356, '02-03-2020', '02-03-2020', 'Central', 745, 'VANDALISM - MISDEAMEANOR ($399 OR UNDER)', 49, 'M', 'OTHER STORE', 'IC', '37TH ST', 34.05, -118.24)
    (200711295, '07-06-2020', '07-05-2020', 'Wilshire', 510, 'VEHICLE - STOLEN', 0, '', 'STREET', 'IC', '1100 W 35TH ST', 34.09, -118.35)
    (201108111, '04-07-2020', '04-07-2020', 'Northeast', 624, 'BATTERY - SIMPLE ASSAULT', 70, 'F', 'SINGLE FAMILY DWELLING', 'AO', 'JEFFERSON BL', 34.13, -118.2)
    (200106377, '02-03-2020', '02-02-2020', 'Central', 624, 'BATTERY - SIMPLE ASSAULT', 22, 'M', 'NIGHT CLUB (OPEN EVENINGS ONLY)', 'IC', '3800 LOCKLAND DR', 34.05, -118.25)
    (200106381, '02-03-2020', '02-03-2020', 'Central', 666, 'BUNCO, ATTEMPT', 28, 'M', 'MULTI-UNIT DWELLING (APARTMENT, DUPLEX, ETC)', 'IC', '4100 S HOOVER ST', 34.05, -118.25)
    (200106382, '02-03-2020', '02-02-2020', 'Central', 330, 'BURGLARY FROM VEHICLE', 26, 'M', 'TRUCK, COMMERICAL', 'IC', '3000 ALSACE AV', 34.05, -118.25)
    (200106383, '02-03-2020', '02-03-2020', 'Central', 330, 'BURGLARY FROM VEHICLE', 23, 'M', 'PARKING LOT', 'IC', '29TH', 34.04, -118.26)
    (200106386, '02-04-2020', '02-03-2020', 'Central', 440, 'THEFT PLAIN - PETTY ($950 & UNDER)', 41, 'M', 'LA UNION STATION (NOT LINE SPECIFIC)', 'IC', '1000 BAY VIEW AV', 34.06, -118.23)
    (200106389, '02-03-2020', '02-01-2020', 'Central', 440, 'THEFT PLAIN - PETTY ($950 & UNDER)', 26, 'F', 'MULTI-UNIT DWELLING (APARTMENT, DUPLEX, ETC)', 'IC', '4500 MARTIN LUTHER KING JR BL', 34.05, -118.25)
    (200106395, '02-02-2020', '02-01-2020', 'Central', 330, 'BURGLARY FROM VEHICLE', 31, 'M', 'VEHICLE, PASSENGER/TRUCK', 'IC', '4000 WEST BL', 34.04, -118.26)
    (200106409, '02-04-2020', '01-04-2020', 'Central', 662, 'BUNCO, GRAND THEFT', 67, 'M', 'OTHER RESIDENCE', 'IC', '4000 CRENSHAW BL', 34.06, -118.24)
    (200106410, '02-04-2020', '02-03-2020', 'Central', 662, 'BUNCO, GRAND THEFT', 67, 'M', 'MULTI-UNIT DWELLING (APARTMENT, DUPLEX, ETC)', 'IC', '2300 W JEFFERSON BL', 34.06, -118.24)
    (200106412, '02-04-2020', '02-03-2020', 'Central', 341, 'THEFT-GRAND ($950.01 & OVER)EXCPT,GUNS,FOWL,LIVESTK,PROD', 41, 'M', 'HEALTH SPA/GYM', 'IC', '1600 W 35TH ST', 34.05, -118.26)
    (200106414, '02-04-2020', '02-04-2020', 'Central', 956, 'LETTERS, LEWD  -  TELEPHONE CALLS, LEWD', 28, 'F', 'OTHER RESIDENCE', 'IC', '700 W 30TH ST', 34.04, -118.25)
    (200106420, '02-04-2020', '02-03-2020', 'Central', 330, 'BURGLARY FROM VEHICLE', 51, 'F', 'STREET', 'IC', '5000 EXPOSITION BL', 34.04, -118.27)
    (200106425, '02-04-2020', '02-04-2020', 'Central', 623, 'BATTERY POLICE (SIMPLE)', 0, 'M', 'STREET', 'IC', '7300 SAUSALITO AV', 34.05, -118.23)
    (200505554, '02-07-2020', '02-06-2020', 'Harbor', 510, 'VEHICLE - STOLEN', 0, 'F', 'STREET', 'IC', '16100 VANOWEN ST', 33.75, -118.3)
    (200915605, '10-06-2020', '10-06-2020', 'Van Nuys', 354, 'THEFT OF IDENTITY', 33, 'M', 'PARKING LOT', 'IC', '400 N EVERGREEN AV', 34.16, -118.44)
    (200106479, '02-04-2020', '02-03-2020', 'Central', 330, 'BURGLARY FROM VEHICLE', 46, 'M', 'PARKING LOT', 'IC', '13400 TERRA BELLA ST', 34.05, -118.25)
    (200106427, '02-04-2020', '02-04-2020', 'Central', 624, 'BATTERY - SIMPLE ASSAULT', 52, 'M', 'SIDEWALK', 'IC', '19100 JOVAN ST', 34.04, -118.25)
    (200106446, '02-04-2020', '02-04-2020', 'Central', 420, 'THEFT FROM MOTOR VEHICLE - PETTY ($950 & UNDER)', 0, 'X', 'STREET', 'IC', '1900 SELBY AV', 34.05, -118.24)
    (200106448, '02-04-2020', '02-04-2020', 'Central', 351, 'PURSE SNATCHING', 56, 'F', 'SIDEWALK', 'IC', '100 W AVENUE 44', 34.06, -118.24)
    (200106449, '02-05-2020', '02-05-2020', 'Central', 888, 'TRESPASSING', 40, 'M', 'TUNNEL', 'IC', '5900 MONTEREY RD', 34.05, -118.25)
    (200106450, '02-04-2020', '02-04-2020', 'Central', 442, 'SHOPLIFTING - PETTY THEFT ($950 & UNDER)', 35, 'M', 'DEPARTMENT STORE', 'IC', '5600 W SUNSET BL', 34.05, -118.26)
    (200106452, '02-04-2020', '02-04-2020', 'Central', 310, 'BURGLARY', 57, 'F', 'JEWELRY STORE', 'IC', '1300 MIDVALE AV', 34.05, -118.25)
    (200106453, '02-04-2020', '02-04-2020', 'Central', 440, 'THEFT PLAIN - PETTY ($950 & UNDER)', 23, 'M', 'SIDEWALK', 'IC', 'EDGEMONT', 34.05, -118.26)
    (200513966, '09-08-2020', '09-04-2020', 'Harbor', 745, 'VANDALISM - MISDEAMEANOR ($399 OR UNDER)', 0, 'M', 'CHURCH/CHAPEL (CHANGED 03-03 FROM CHURCH/TEMPLE)', 'IC', '10700 WEYBURN AV', 33.74, -118.29)
    (200106460, '02-04-2020', '02-04-2020', 'Central', 440, 'THEFT PLAIN - PETTY ($950 & UNDER)', 31, 'F', 'CLOTHING STORE', 'IC', 'WILSHIRE', 34.05, -118.26)
    (200107002, '02-12-2020', '02-11-2020', 'Central', 330, 'BURGLARY FROM VEHICLE', 28, 'M', 'STREET', 'IC', '9900 SATICOY ST', 34.05, -118.25)
    (200106463, '02-04-2020', '02-04-2020', 'Central', 310, 'BURGLARY', 26, 'M', 'BAR/SPORTS BAR (OPEN DAY & NIGHT)', 'IC', '5900 SPELTHORNE LN', 34.06, -118.24)
    (200516175, '11-04-2020', '11-04-2020', 'Harbor', 510, 'VEHICLE - STOLEN', 0, 'F', 'PARKING LOT', 'IC', 'CHEROKEE', 33.8, -118.3)
    (200813946, '09-10-2020', '09-08-2020', 'West LA', 310, 'BURGLARY', 66, 'F', 'SINGLE FAMILY DWELLING', 'IC', '600 N SAN FERNANDO RD', 34.04, -118.4)
    (200106478, '02-03-2020', '02-03-2020', 'Central', 330, 'BURGLARY FROM VEHICLE', 39, 'M', 'PARKING LOT', 'IC', '2700 S GRAND AV', 34.05, -118.26)
    (200106480, '02-04-2020', '02-03-2020', 'Central', 330, 'BURGLARY FROM VEHICLE', 32, 'M', 'STREET', 'IC', '700 IMOGEN AV', 34.04, -118.25)
    (200106484, '02-05-2020', '02-05-2020', 'Central', 761, 'BRANDISH WEAPON', 63, 'M', 'SIDEWALK', 'IC', 'ROSALIND PL', 34.06, -118.24)
    (200106485, '02-05-2020', '02-01-2020', 'Central', 341, 'THEFT-GRAND ($950.01 & OVER)EXCPT,GUNS,FOWL,LIVESTK,PROD', 55, 'M', 'SIDEWALK', 'IC', 'GRAND AV', 34.04, -118.26)
    (200106488, '02-05-2020', '02-05-2020', 'Central', 510, 'VEHICLE - STOLEN', 0, 'M', 'STREET', 'IC', '10300 COMPTON AV', 34.07, -118.23)
    (200106492, '02-05-2020', '02-04-2020', 'Central', 330, 'BURGLARY FROM VEHICLE', 58, 'F', 'PARKING UNDERGROUND/BUILDING', 'IC', '1300 W C ST', 34.04, -118.26)
    (200106494, '02-05-2020', '02-05-2020', 'Central', 624, 'BATTERY - SIMPLE ASSAULT', 58, 'M', 'LAUNDROMAT', 'IC', '2900 W OLYMPIC BL', 34.04, -118.24)
    (200106495, '02-04-2020', '02-04-2020', 'Central', 343, 'SHOPLIFTING-GRAND THEFT ($950.01 & OVER)', 24, 'M', 'OTHER STORE', 'IC', '10900 SANTA MONICA BL', 34.05, -118.26)
    (200106500, '02-05-2020', '02-05-2020', 'Central', 624, 'BATTERY - SIMPLE ASSAULT', 25, 'F', 'SIDEWALK', 'IC', '5000 OBAMA BL', 34.04, -118.24)
    (200106501, '02-05-2020', '02-04-2020', 'Central', 310, 'BURGLARY', 61, 'M', 'MULTI-UNIT DWELLING (APARTMENT, DUPLEX, ETC)', 'IC', '3100 S FIGUEROA ST', 34.04, -118.25)
    (200106507, '02-05-2020', '02-05-2020', 'Central', 624, 'BATTERY - SIMPLE ASSAULT', 23, 'M', 'MULTI-UNIT DWELLING (APARTMENT, DUPLEX, ETC)', 'IC', '3900 URSULA AV', 34.04, -118.24)
    (200106514, '02-05-2020', '02-05-2020', 'Central', 230, 'ASSAULT WITH DEADLY WEAPON, AGGRAVATED ASSAULT', 45, 'M', 'STREET', 'IC', '4000 ABOURNE RD', 34.04, -118.25)
    (200705720, '02-05-2020', '02-01-2020', 'Wilshire', 341, 'THEFT-GRAND ($950.01 & OVER)EXCPT,GUNS,FOWL,LIVESTK,PROD', 0, 'M', 'OTHER BUSINESS', 'IC', '1000 W 34TH ST', 34.07, -118.37)
    (200106516, '02-05-2020', '02-05-2020', 'Central', 330, 'BURGLARY FROM VEHICLE', 33, 'M', 'STREET', 'IC', '126TH ST', 34.07, -118.24)
    (200106517, '02-05-2020', '02-05-2020', 'Central', 330, 'BURGLARY FROM VEHICLE', 78, 'F', 'GARAGE/CARPORT', 'IC', '400 S SOTO ST', 34.05, -118.26)
    (211104260, '01-08-2021', '12-02-2020', 'Northeast', 310, 'BURGLARY', 0, 'X', 'OFFICE BUILDING/OFFICE', 'AO', '700 STATE DR', 34.11, -118.24)
    (200106519, '02-05-2020', '02-05-2020', 'Central', 330, 'BURGLARY FROM VEHICLE', 24, 'F', 'STREET', 'IC', '3700 CARMONA AV', 34.05, -118.24)
    (200106520, '02-05-2020', '02-05-2020', 'Central', 624, 'BATTERY - SIMPLE ASSAULT', 43, 'M', 'MULTI-UNIT DWELLING (APARTMENT, DUPLEX, ETC)', 'IC', '5100 OBAMA BL', 34.05, -118.26)
    (200106526, '02-05-2020', '02-05-2020', 'Central', 442, 'SHOPLIFTING - PETTY THEFT ($950 & UNDER)', 35, 'M', 'DEPARTMENT STORE', 'IC', '4300 3RD AV', 34.05, -118.26)
    (200106527, '02-05-2020', '02-04-2020', 'Central', 480, 'BIKE - STOLEN', 27, 'M', 'STREET', 'IC', '4700 7TH AV', 34.05, -118.26)
    (200106531, '02-05-2020', '02-05-2020', 'Central', 624, 'BATTERY - SIMPLE ASSAULT', 49, 'M', 'OTHER STORE', 'IC', '3600 W MARTIN LUTHER KING JR BL', 34.05, -118.26)
    (200106534, '02-05-2020', '02-05-2020', 'Central', 888, 'TRESPASSING', 0, 'X', 'LA UNION STATION (NOT LINE SPECIFIC)', 'IC', '1600 W MARTIN LUTHER KING BL', 34.06, -118.24)
    (200106547, '02-05-2020', '02-04-2020', 'Central', 330, 'BURGLARY FROM VEHICLE', 62, 'M', 'PARKING LOT', 'IC', '4300 S FIGUEROA ST', 34.05, -118.26)
    (200106548, '02-06-2020', '02-05-2020', 'Central', 330, 'BURGLARY FROM VEHICLE', 35, 'M', 'ABANDONED BUILDING ABANDONED HOUSE', 'IC', 'BUCKINGHAM', 34.07, -118.23)
    (200709141, '05-11-2020', '05-11-2020', 'Wilshire', 440, 'THEFT PLAIN - PETTY ($950 & UNDER)', 48, 'M', 'PHARMACY INSIDE STORE OR SUPERMARKET*', 'IC', 'KENILWORTH AV', 34.08, -118.35)
    (200605994, '02-11-2020', '02-10-2020', 'Hollywood', 440, 'THEFT PLAIN - PETTY ($950 & UNDER)', 31, 'F', 'YARD (RESIDENTIAL/BUSINESS)', 'IC', '3900 S VAN NESS AV', 34.1, -118.3)
    (200106584, '02-06-2020', '02-06-2020', 'Central', 740, 'VANDALISM - FELONY ($400 & OVER, ALL CHURCH VANDALISMS)', 57, 'M', 'MTA PROPERTY OR PARKING LOT', 'IC', '1100 HARTZELL ST', 34.07, -118.23)
    (200106593, '02-06-2020', '02-06-2020', 'Central', 442, 'SHOPLIFTING - PETTY THEFT ($950 & UNDER)', 23, 'M', 'OTHER STORE', 'IC', '4100 S BUDLONG AV', 34.05, -118.26)
    (201105686, '02-08-2020', '02-07-2020', 'Northeast', 440, 'THEFT PLAIN - PETTY ($950 & UNDER)', 0, 'M', 'OTHER BUSINESS', 'IC', 'FIGUEROA ST', 34.14, -118.23)
    (200106598, '02-06-2020', '02-06-2020', 'Central', 442, 'SHOPLIFTING - PETTY THEFT ($950 & UNDER)', 0, 'X', 'DEPARTMENT STORE', 'IC', '1200 W 39TH ST', 34.05, -118.26)
    (200106599, '02-06-2020', '02-06-2020', 'Central', 442, 'SHOPLIFTING - PETTY THEFT ($950 & UNDER)', 0, 'X', 'DEPARTMENT STORE', 'IC', 'VERNON AV', 34.05, -118.26)
    (200106600, '02-06-2020', '02-06-2020', 'Central', 624, 'BATTERY - SIMPLE ASSAULT', 56, 'F', 'SIDEWALK', 'IC', '4200 S WESTERN AV', 34.04, -118.24)
    (200106604, '02-07-2020', '02-06-2020', 'Central', 888, 'TRESPASSING', 0, 'M', 'LA UNION STATION (NOT LINE SPECIFIC)', 'IC', '4000 SANTO TOMAS DR', 34.06, -118.24)
    (200106606, '02-07-2020', '02-07-2020', 'Central', 624, 'BATTERY - SIMPLE ASSAULT', 75, 'F', 'SIDEWALK', 'IC', '600 EXPOSITION BL', 34.04, -118.24)
    (200106608, '02-07-2020', '02-07-2020', 'Central', 510, 'VEHICLE - STOLEN', 0, 'M', 'STREET', 'IC', '1400 W 37TH DR', 34.05, -118.25)
    (200106614, '02-07-2020', '02-07-2020', 'Central', 624, 'BATTERY - SIMPLE ASSAULT', 33, 'M', 'SIDEWALK', 'IC', '2400 ELLENDALE PL', 34.05, -118.26)
    (200106615, '02-07-2020', '02-07-2020', 'Central', 624, 'BATTERY - SIMPLE ASSAULT', 25, 'M', 'SIDEWALK', 'IC', '39TH PL', 34.05, -118.26)
    (200106616, '02-07-2020', '02-07-2020', 'Central', 624, 'BATTERY - SIMPLE ASSAULT', 35, 'M', 'OTHER STORE', 'IC', '2500 W VERNON AV', 34.05, -118.25)
    (200106617, '02-07-2020', '01-10-2020', 'Central', 510, 'VEHICLE - STOLEN', 0, 'F', 'PARKING LOT', 'IC', '700 EXPOSITION BL', 34.05, -118.25)
    (200106618, '02-07-2020', '02-03-2020', 'Central', 745, 'VANDALISM - MISDEAMEANOR ($399 OR UNDER)', 72, 'M', 'VEHICLE, PASSENGER/TRUCK', 'IC', '2600 S FIGUEROA ST', 34.05, -118.24)
    


```python
sql_vic = cursor.execute('select Vict_Age, count(*) as crime_count from crime_data group by Vict_Age;')
rows = cursor.fetchall()
for row in rows:
    print(row)
```

    (36, 8)
    (25, 13)
    (76, 1)
    (31, 13)
    (23, 15)
    (0, 90)
    (29, 14)
    (35, 17)
    (41, 7)
    (24, 10)
    (40, 7)
    (19, 6)
    (38, 13)
    (55, 9)
    (66, 2)
    (34, 9)
    (44, 5)
    (57, 13)
    (22, 12)
    (28, 16)
    (43, 6)
    (46, 3)
    (56, 9)
    (67, 5)
    (37, 8)
    (60, 5)
    (51, 5)
    (52, 3)
    (61, 5)
    (59, 5)
    (32, 13)
    (30, 15)
    (50, 5)
    (45, 9)
    (62, 5)
    (20, 5)
    (58, 7)
    (27, 12)
    (48, 7)
    (18, 2)
    (26, 19)
    (47, 3)
    (21, 3)
    (64, 4)
    (39, 6)
    (75, 2)
    (12, 2)
    (49, 5)
    (71, 3)
    (68, 2)
    (69, 2)
    (13, 1)
    (33, 9)
    (53, 5)
    (74, 1)
    (65, 2)
    (54, 2)
    (8, 1)
    (9, 1)
    (63, 2)
    (17, 1)
    (73, 2)
    (42, 3)
    (72, 2)
    (70, 1)
    (78, 1)
    


```python
df = pd.read_csv('crime_data.csv')
```


```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>DR_NO</th>
      <th>Date_Rptd</th>
      <th>DATE_OCC</th>
      <th>AREA_NAME</th>
      <th>Crm_Cd</th>
      <th>Crm_Cd_Desc</th>
      <th>Vict_Age</th>
      <th>Vict_Sex</th>
      <th>Premis_Desc</th>
      <th>Status</th>
      <th>Location</th>
      <th>LAT</th>
      <th>LON</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>10304468</td>
      <td>01-08-2020</td>
      <td>01-08-2020</td>
      <td>Southwest</td>
      <td>624</td>
      <td>BATTERY - SIMPLE ASSAULT</td>
      <td>36</td>
      <td>F</td>
      <td>SINGLE FAMILY DWELLING</td>
      <td>AO</td>
      <td>1100 W 39TH PL</td>
      <td>34.01</td>
      <td>-118.30</td>
    </tr>
    <tr>
      <th>1</th>
      <td>190101086</td>
      <td>01-02-2020</td>
      <td>01-01-2020</td>
      <td>Central</td>
      <td>624</td>
      <td>BATTERY - SIMPLE ASSAULT</td>
      <td>25</td>
      <td>M</td>
      <td>SIDEWALK</td>
      <td>IC</td>
      <td>700 S HILL ST</td>
      <td>34.05</td>
      <td>-118.25</td>
    </tr>
    <tr>
      <th>2</th>
      <td>191501505</td>
      <td>01-01-2020</td>
      <td>01-01-2020</td>
      <td>N Hollywood</td>
      <td>745</td>
      <td>VANDALISM - MISDEAMEANOR ($399 OR UNDER)</td>
      <td>76</td>
      <td>F</td>
      <td>MULTI-UNIT DWELLING (APARTMENT, DUPLEX, ETC)</td>
      <td>IC</td>
      <td>5400 CORTEEN PL</td>
      <td>34.17</td>
      <td>-118.40</td>
    </tr>
    <tr>
      <th>3</th>
      <td>191921269</td>
      <td>01-01-2020</td>
      <td>01-01-2020</td>
      <td>Mission</td>
      <td>740</td>
      <td>VANDALISM - FELONY ($400 &amp; OVER, ALL CHURCH VA...</td>
      <td>31</td>
      <td>X</td>
      <td>BEAUTY SUPPLY STORE</td>
      <td>IC</td>
      <td>14400 TITUS ST</td>
      <td>34.22</td>
      <td>-118.45</td>
    </tr>
    <tr>
      <th>4</th>
      <td>200100502</td>
      <td>01-02-2020</td>
      <td>01-02-2020</td>
      <td>Central</td>
      <td>442</td>
      <td>SHOPLIFTING - PETTY THEFT ($950 &amp; UNDER)</td>
      <td>23</td>
      <td>M</td>
      <td>DEPARTMENT STORE</td>
      <td>IC</td>
      <td>700 S FIGUEROA ST</td>
      <td>34.05</td>
      <td>-118.26</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.shape
```




    (499, 13)




```python
df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 499 entries, 0 to 498
    Data columns (total 13 columns):
     #   Column       Non-Null Count  Dtype  
    ---  ------       --------------  -----  
     0   DR_NO        499 non-null    int64  
     1   Date_Rptd    499 non-null    object 
     2   DATE_OCC     499 non-null    object 
     3   AREA_NAME    499 non-null    object 
     4   Crm_Cd       499 non-null    int64  
     5   Crm_Cd_Desc  499 non-null    object 
     6   Vict_Age     499 non-null    int64  
     7   Vict_Sex     472 non-null    object 
     8   Premis_Desc  499 non-null    object 
     9   Status       499 non-null    object 
     10  Location     499 non-null    object 
     11  LAT          499 non-null    float64
     12  LON          499 non-null    float64
    dtypes: float64(2), int64(3), object(8)
    memory usage: 50.8+ KB
    


```python
df.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>DR_NO</th>
      <th>Crm_Cd</th>
      <th>Vict_Age</th>
      <th>LAT</th>
      <th>LON</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>4.990000e+02</td>
      <td>499.000000</td>
      <td>499.000000</td>
      <td>499.000000</td>
      <td>499.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>1.999930e+08</td>
      <td>504.178357</td>
      <td>32.142285</td>
      <td>34.047335</td>
      <td>-118.261283</td>
    </tr>
    <tr>
      <th>std</th>
      <td>8.742243e+06</td>
      <td>198.381863</td>
      <td>20.202136</td>
      <td>0.053840</td>
      <td>0.041560</td>
    </tr>
    <tr>
      <th>min</th>
      <td>1.030447e+07</td>
      <td>210.000000</td>
      <td>0.000000</td>
      <td>33.710000</td>
      <td>-118.560000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>2.001044e+08</td>
      <td>330.000000</td>
      <td>23.000000</td>
      <td>34.040000</td>
      <td>-118.260000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>2.001048e+08</td>
      <td>442.000000</td>
      <td>31.000000</td>
      <td>34.050000</td>
      <td>-118.250000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>2.001064e+08</td>
      <td>624.000000</td>
      <td>46.500000</td>
      <td>34.050000</td>
      <td>-118.240000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>2.220130e+08</td>
      <td>956.000000</td>
      <td>78.000000</td>
      <td>34.280000</td>
      <td>-118.190000</td>
    </tr>
  </tbody>
</table>
</div>



# ANALYSIS PART 
QUESTIONS:

# 1. Spatial Analysis:
  Question:
  1.Where are the geographical hotspots for reported crimes?


```python
Q1= ('select LAT, LON, count(*) as Number_of_crime from crime_data group by LAT, LON order by Number_of_crime desc;')
```


```python
cursor.execute(Q1)
```




    81




```python
df1 = pd.read_sql_query(Q1, connection)
```

    C:\Users\User\AppData\Local\Temp\ipykernel_3416\2400420247.py:1: UserWarning: pandas only supports SQLAlchemy connectable (engine/connection) or database string URI or sqlite3 DBAPI2 connection. Other DBAPI2 objects are not tested. Please consider using SQLAlchemy.
      df1 = pd.read_sql_query(Q1, connection)
    


```python
df1.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>LAT</th>
      <th>LON</th>
      <th>Number_of_crime</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>34.05</td>
      <td>-118.26</td>
      <td>95</td>
    </tr>
    <tr>
      <th>1</th>
      <td>34.05</td>
      <td>-118.25</td>
      <td>75</td>
    </tr>
    <tr>
      <th>2</th>
      <td>34.04</td>
      <td>-118.25</td>
      <td>47</td>
    </tr>
    <tr>
      <th>3</th>
      <td>34.06</td>
      <td>-118.24</td>
      <td>43</td>
    </tr>
    <tr>
      <th>4</th>
      <td>34.05</td>
      <td>-118.24</td>
      <td>39</td>
    </tr>
  </tbody>
</table>
</div>




```python
plt.figure(figsize=(10,5))
sns.scatterplot(x='LON', y='LAT', data =df1,label=map)
plt.title('GEOGRAPHICAL CRIME HOTSPOT')
plt.legend()
plt.show()
```


    
![png](output_25_0.png)
    


# 2. VICTIM DEMOGRAPHICS:
    QUESTION -Victim Demographics:

What is the distribution of victim ages in reported crimes?

Is there a significant difference in crime rates between male and female victims?


```python
q2=('select Vict_Age, count(*) as crime_count from crime_data group by Vict_Age order by Crime_count_Reported desc limit 10;')
```


```python
cursor.execute(q2)
```




    10




```python
df2= pd.read_sql_query(q2, connection)
```

    C:\Users\User\AppData\Local\Temp\ipykernel_20936\3534450095.py:1: UserWarning: pandas only supports SQLAlchemy connectable (engine/connection) or database string URI or sqlite3 DBAPI2 connection. Other DBAPI2 objects are not tested. Please consider using SQLAlchemy.
      df2= pd.read_sql_query(q2, connection)
    


```python
type(df2)
```




    pandas.core.frame.DataFrame




```python
df2.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Vict_Age</th>
      <th>crime_count</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>90</td>
    </tr>
    <tr>
      <th>1</th>
      <td>26</td>
      <td>19</td>
    </tr>
    <tr>
      <th>2</th>
      <td>35</td>
      <td>17</td>
    </tr>
    <tr>
      <th>3</th>
      <td>28</td>
      <td>16</td>
    </tr>
    <tr>
      <th>4</th>
      <td>23</td>
      <td>15</td>
    </tr>
  </tbody>
</table>
</div>




```python
sns.barplot(x="Vict_Age", y="crime_count", data =df2)
plt.title("AGE DISTRIBUTION")
plt.show()
```


    
![png](output_32_0.png)
    


# 2B.Is there a significant difference in crime rates between male and female victims?



```python
Q3 =('select Vict_Sex AS GENDER, count(*) AS Crime_count, count(*) * 100.0 / sum(count(*)) OVER() AS Crime_rate_percentage from crime_data group by Vict_Sex;')

```


```python
cursor.execute(Q3)
```




    4




```python
df3= pd.read_sql_query(Q3, connection)
```

    C:\Users\User\AppData\Local\Temp\ipykernel_3416\272782611.py:1: UserWarning: pandas only supports SQLAlchemy connectable (engine/connection) or database string URI or sqlite3 DBAPI2 connection. Other DBAPI2 objects are not tested. Please consider using SQLAlchemy.
      df3= pd.read_sql_query(Q3, connection)
    


```python
sns.barplot(x="GENDER", y="Crime_count", data = df3,hue="Crime_rate_percentage")
plt.title('Crime Rate between Male and Female')
plt.show()
```


    
![png](output_37_0.png)
    


# 3. Location Based Analysis
Location Analysis:

Where do most crimes occur based on the "Location" column?


```python
Q4=('select Location, count(*) as Most_Crime_no from crime_data group by Location order by Most_Crime_no desc limit 10;')
```


```python
cursor.execute(Q4)
```




    10




```python
df4 = pd.read_sql_query(Q4, connection)
```

    C:\Users\User\AppData\Local\Temp\ipykernel_20936\3549857663.py:1: UserWarning: pandas only supports SQLAlchemy connectable (engine/connection) or database string URI or sqlite3 DBAPI2 connection. Other DBAPI2 objects are not tested. Please consider using SQLAlchemy.
      df4 = pd.read_sql_query(Q4, connection)
    


```python
df4
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Location</th>
      <th>Most_Crime_no</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>800 N ALAMEDA ST</td>
      <td>14</td>
    </tr>
    <tr>
      <th>1</th>
      <td>700 W 7TH ST</td>
      <td>11</td>
    </tr>
    <tr>
      <th>2</th>
      <td>300 E 5TH ST</td>
      <td>6</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1100 S FIGUEROA ST</td>
      <td>6</td>
    </tr>
    <tr>
      <th>4</th>
      <td>6TH</td>
      <td>6</td>
    </tr>
    <tr>
      <th>5</th>
      <td>600 S SPRING ST</td>
      <td>5</td>
    </tr>
    <tr>
      <th>6</th>
      <td>100 E 5TH ST</td>
      <td>5</td>
    </tr>
    <tr>
      <th>7</th>
      <td>7TH ST</td>
      <td>5</td>
    </tr>
    <tr>
      <th>8</th>
      <td>500 S SAN PEDRO ST</td>
      <td>5</td>
    </tr>
    <tr>
      <th>9</th>
      <td>800 W OLYMPIC BL</td>
      <td>4</td>
    </tr>
  </tbody>
</table>
</div>




```python
plt.figure(figsize=(18,5))
sns.barplot(x="Location", y="Most_Crime_no", data =df4)
plt.title('LOCATION BASED CRIME')
plt.show()
```


    
![png](output_43_0.png)
    


# 4.Crime Code Analysis:

What is the distribution of reported crimes based on Crime Code?


```python
Q5 =('select Crm_cd, count(Crm_cd) as Reported_Crime from crime_data group by Crm_Cd order by Reported_Crime desc limit 10;')
```


```python
cursor.execute(Q5)
```




    10




```python
df5 = pd.read_sql_query(Q5, connection)
```

    C:\Users\User\AppData\Local\Temp\ipykernel_20936\1201523460.py:1: UserWarning: pandas only supports SQLAlchemy connectable (engine/connection) or database string URI or sqlite3 DBAPI2 connection. Other DBAPI2 objects are not tested. Please consider using SQLAlchemy.
      df5 = pd.read_sql_query(Q5, connection)
    


```python
df5
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Crm_cd</th>
      <th>Reported_Crime</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>330</td>
      <td>82</td>
    </tr>
    <tr>
      <th>1</th>
      <td>624</td>
      <td>74</td>
    </tr>
    <tr>
      <th>2</th>
      <td>440</td>
      <td>44</td>
    </tr>
    <tr>
      <th>3</th>
      <td>442</td>
      <td>28</td>
    </tr>
    <tr>
      <th>4</th>
      <td>510</td>
      <td>28</td>
    </tr>
    <tr>
      <th>5</th>
      <td>341</td>
      <td>26</td>
    </tr>
    <tr>
      <th>6</th>
      <td>230</td>
      <td>24</td>
    </tr>
    <tr>
      <th>7</th>
      <td>745</td>
      <td>23</td>
    </tr>
    <tr>
      <th>8</th>
      <td>740</td>
      <td>23</td>
    </tr>
    <tr>
      <th>9</th>
      <td>888</td>
      <td>19</td>
    </tr>
  </tbody>
</table>
</div>




```python
plt.figure(figsize=(5, 15))
plt.pie(df5["Reported_Crime"], labels=df5["Crm_cd"], autopct ='%1.1f%%', startangle=90)
plt.title("CRIME DISTRIBUTION")
plt.show()
```


    
![png](output_49_0.png)
    


# END
